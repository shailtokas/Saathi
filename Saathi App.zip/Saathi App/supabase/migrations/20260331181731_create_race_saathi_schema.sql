/*
  # RACE Saathi - Initial Database Schema

  ## Overview
  Complete database schema for RACE Saathi app - connecting seniors with local volunteers

  ## New Tables
  
  ### 1. `profiles`
  User profiles extending Supabase auth.users
  - `id` (uuid, FK to auth.users) - User ID
  - `phone` (text) - Phone number for contact
  - `full_name` (text) - User's full name
  - `role` (text) - 'senior' or 'volunteer'
  - `area` (text) - Location/area name
  - `pin_code` (text) - Postal code for area filtering
  - `whatsapp_number` (text) - WhatsApp contact
  - `profile_photo_url` (text) - Profile picture URL
  - `language_preference` (text) - 'en' or 'hi'
  - `created_at` (timestamptz) - Account creation time
  - `updated_at` (timestamptz) - Last profile update

  ### 2. `volunteers`
  Extended profile information for volunteers
  - `id` (uuid, PK) - Volunteer ID
  - `user_id` (uuid, FK to profiles) - Link to user profile
  - `is_verified` (boolean) - Manual verification badge
  - `help_description` (text) - What help they can provide
  - `available_categories` (text[]) - Array of help categories
  - `is_active` (boolean) - Currently accepting requests
  - `total_helps` (integer) - Count of completed helps
  - `created_at` (timestamptz) - Registration time

  ### 3. `help_requests`
  Help requests from seniors to volunteers
  - `id` (uuid, PK) - Request ID
  - `senior_id` (uuid, FK to profiles) - Senior who needs help
  - `volunteer_id` (uuid, FK to volunteers) - Assigned volunteer (nullable)
  - `title` (text) - Request title
  - `description` (text) - Detailed description
  - `category` (text) - medicine/doctor/grocery/talk
  - `area` (text) - Location area
  - `pin_code` (text) - Postal code
  - `urgency` (text) - low/medium/high
  - `status` (text) - open/in_progress/completed
  - `created_at` (timestamptz) - Request creation time
  - `updated_at` (timestamptz) - Last status update

  ### 4. `sos_contacts`
  Emergency contacts for users
  - `id` (uuid, PK) - Contact ID
  - `user_id` (uuid, FK to profiles) - User who owns this contact
  - `contact_name` (text) - Emergency contact name
  - `contact_phone` (text) - Phone number
  - `contact_whatsapp` (text) - WhatsApp number
  - `is_primary` (boolean) - Primary emergency contact
  - `created_at` (timestamptz) - Added time

  ## Security
  - RLS enabled on all tables
  - Users can read/update their own profiles
  - Seniors can view volunteers in their area
  - Volunteers can view help requests in their area
  - Users can manage their own help requests and SOS contacts
*/

-- Create profiles table
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  phone text NOT NULL,
  full_name text NOT NULL,
  role text NOT NULL CHECK (role IN ('senior', 'volunteer')),
  area text NOT NULL,
  pin_code text NOT NULL,
  whatsapp_number text,
  profile_photo_url text,
  language_preference text DEFAULT 'en' CHECK (language_preference IN ('en', 'hi')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view all profiles"
  ON profiles FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can insert own profile"
  ON profiles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

-- Create volunteers table
CREATE TABLE IF NOT EXISTS volunteers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid UNIQUE NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  is_verified boolean DEFAULT false,
  help_description text,
  available_categories text[] DEFAULT ARRAY[]::text[],
  is_active boolean DEFAULT true,
  total_helps integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE volunteers ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view active volunteers"
  ON volunteers FOR SELECT
  TO authenticated
  USING (is_active = true);

CREATE POLICY "Volunteers can update own profile"
  ON volunteers FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can insert volunteer profile"
  ON volunteers FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

-- Create help_requests table
CREATE TABLE IF NOT EXISTS help_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  senior_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  volunteer_id uuid REFERENCES volunteers(id) ON DELETE SET NULL,
  title text NOT NULL,
  description text NOT NULL,
  category text NOT NULL CHECK (category IN ('medicine', 'doctor', 'grocery', 'talk')),
  area text NOT NULL,
  pin_code text NOT NULL,
  urgency text NOT NULL DEFAULT 'medium' CHECK (urgency IN ('low', 'medium', 'high')),
  status text NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'in_progress', 'completed')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE help_requests ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Seniors can view own requests"
  ON help_requests FOR SELECT
  TO authenticated
  USING (senior_id = auth.uid());

CREATE POLICY "Volunteers can view requests in their area"
  ON help_requests FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles p
      WHERE p.id = auth.uid() 
      AND p.role = 'volunteer'
      AND p.area = help_requests.area
    )
  );

CREATE POLICY "Seniors can create help requests"
  ON help_requests FOR INSERT
  TO authenticated
  WITH CHECK (senior_id = auth.uid());

CREATE POLICY "Seniors can update own requests"
  ON help_requests FOR UPDATE
  TO authenticated
  USING (senior_id = auth.uid())
  WITH CHECK (senior_id = auth.uid());

CREATE POLICY "Volunteers can update assigned requests"
  ON help_requests FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM volunteers v
      WHERE v.id = help_requests.volunteer_id
      AND v.user_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM volunteers v
      WHERE v.id = help_requests.volunteer_id
      AND v.user_id = auth.uid()
    )
  );

-- Create sos_contacts table
CREATE TABLE IF NOT EXISTS sos_contacts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  contact_name text NOT NULL,
  contact_phone text NOT NULL,
  contact_whatsapp text,
  is_primary boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE sos_contacts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own SOS contacts"
  ON sos_contacts FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can create own SOS contacts"
  ON sos_contacts FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can update own SOS contacts"
  ON sos_contacts FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can delete own SOS contacts"
  ON sos_contacts FOR DELETE
  TO authenticated
  USING (user_id = auth.uid());

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_profiles_role ON profiles(role);
CREATE INDEX IF NOT EXISTS idx_profiles_area ON profiles(area);
CREATE INDEX IF NOT EXISTS idx_profiles_pin_code ON profiles(pin_code);
CREATE INDEX IF NOT EXISTS idx_volunteers_user_id ON volunteers(user_id);
CREATE INDEX IF NOT EXISTS idx_volunteers_active ON volunteers(is_active);
CREATE INDEX IF NOT EXISTS idx_help_requests_senior_id ON help_requests(senior_id);
CREATE INDEX IF NOT EXISTS idx_help_requests_volunteer_id ON help_requests(volunteer_id);
CREATE INDEX IF NOT EXISTS idx_help_requests_status ON help_requests(status);
CREATE INDEX IF NOT EXISTS idx_help_requests_area ON help_requests(area);
CREATE INDEX IF NOT EXISTS idx_sos_contacts_user_id ON sos_contacts(user_id);