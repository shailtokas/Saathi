# Architecture Diagram - Session Persistence Fix

## Before Fix (Broken Flow)

```
┌─────────────────────────────────────────────────────────────┐
│                     USER FLOW (BROKEN)                      │
└─────────────────────────────────────────────────────────────┘

1. Login/Signup
   ├─ Phone + OTP ✓
   ├─ Profile Created ✓
   └─ Redirect to Home ✓

2. Page Reload
   ├─ AuthContext checks Supabase Auth ✗ (doesn't exist)
   ├─ No session found ✗
   ├─ Phone lost (was in URL params) ✗
   ├─ Profile not loaded ✗
   └─ User logged out ✗

Result: USER MUST LOGIN AGAIN ❌
```

## After Fix (Working Flow)

```
┌─────────────────────────────────────────────────────────────┐
│                    USER FLOW (FIXED)                        │
└─────────────────────────────────────────────────────────────┘

1. Login/Signup
   ├─ Phone + OTP ✓
   ├─ Profile Created ✓
   ├─ Session Saved to localStorage ✓
   │  └─ {phone, userId, role, timestamp}
   └─ Redirect to Home ✓

2. Page Reload
   ├─ AuthContext checks localStorage ✓
   ├─ Session found ✓
   │  └─ {phone: "+91...", userId: "abc-123", role: "senior"}
   ├─ Load profile from DB by userId ✓
   ├─ Profile loaded ✓
   └─ Auto-redirect to Home ✓

Result: USER STAYS LOGGED IN ✅
```

## Component Architecture

```
┌────────────────────────────────────────────────────────────────┐
│                         APP STRUCTURE                          │
└────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│ _layout.tsx (Root)                                              │
│  ├─ AuthProvider (contexts/AuthContext.tsx)                     │
│  │   ├─ useState: session, user, profile, phoneSession          │
│  │   ├─ useEffect: Check localStorage on mount                  │
│  │   └─ refreshProfile(): Load from DB                          │
│  └─ LanguageProvider                                            │
│      └─ Stack Navigator                                         │
│          ├─ index.tsx (Landing)                                 │
│          ├─ login.tsx                                           │
│          ├─ setup-profile.tsx                                   │
│          ├─ (senior)/_layout.tsx → Tabs                         │
│          └─ (volunteer)/_layout.tsx → Tabs                      │
└─────────────────────────────────────────────────────────────────┘
```

## Data Flow Diagram

```
┌────────────────────────────────────────────────────────────────┐
│                      SESSION DATA FLOW                         │
└────────────────────────────────────────────────────────────────┘

┌──────────────┐      ┌──────────────┐      ┌──────────────┐
│  User Login  │      │   Profile    │      │  localStorage│
│   (OTP)      │─────▶│   Created    │─────▶│   Session    │
└──────────────┘      └──────────────┘      │   Saved      │
                                             └──────┬───────┘
                                                    │
                      ┌─────────────────────────────┘
                      │
                      ▼
┌──────────────┐      ┌──────────────┐      ┌──────────────┐
│ Page Reload  │─────▶│ Check Local  │─────▶│ Load Profile │
│              │      │  Storage     │      │  from DB     │
└──────────────┘      └──────────────┘      └──────┬───────┘
                                                    │
                      ┌─────────────────────────────┘
                      │
                      ▼
                  ┌──────────────┐
                  │ Auto-Redirect│
                  │   to Home    │
                  └──────────────┘
```

## Session Storage Structure

```javascript
// localStorage['race_saathi_session']
{
  "phone": "+919876543210",      // User's phone number
  "userId": "abc-123-def-456",   // Profile ID (UUID)
  "role": "senior",              // 'senior' or 'volunteer'
  "timestamp": 1712047200000     // Created timestamp (ms)
}

// Validation
- timestamp checked on retrieval
- expires after 24 hours
- cleared on logout
```

## Database Schema (Simplified)

```sql
-- profiles table (after migration)
profiles
├─ id (uuid) PRIMARY KEY
│  └─ NO FOREIGN KEY to auth.users ✓
├─ phone (text) UNIQUE ✓
├─ full_name (text)
├─ role (text) 'senior' | 'volunteer'
├─ area, pin_code
└─ created_at, updated_at

-- RLS Policies (after migration)
FOR SELECT: TO anon, authenticated USING (true)
FOR INSERT: TO anon, authenticated WITH CHECK (true)
FOR UPDATE: TO anon, authenticated USING/WITH CHECK (true)
```

## Authentication Flow Comparison

```
┌─────────────────────────────────────────────────────────────┐
│           TRADITIONAL vs PHONE-BASED AUTH                   │
└─────────────────────────────────────────────────────────────┘

TRADITIONAL (Email/Password)          PHONE-BASED (This App)
─────────────────────────────────     ──────────────────────────
1. Email + Password                   1. Phone + OTP
2. Supabase Auth creates user         2. 2Factor.in verifies OTP
3. Session: JWT token                 3. Session: localStorage
4. Profile linked to auth.users       4. Profile standalone
5. RLS: auth.uid()                    5. RLS: anon role
6. Auto-session management            6. Custom session mgmt

✓ More secure (JWT)                   ✓ Simpler (no auth setup)
✓ Built-in features                   ✓ Faster implementation
✗ Complex setup                       ✗ Manual session handling
✗ Requires email                      ✗ Need custom expiry
```

## File Dependencies

```
app/index.tsx
    ├─ useAuth() → contexts/AuthContext.tsx
    │               ├─ getSession() → lib/session.ts
    │               └─ supabase → lib/supabase.ts
    └─ Auto-navigate based on profile

app/login.tsx
    ├─ send2FactorOTP() → lib/2factor.ts
    ├─ verify2FactorOTP() → lib/2factor.ts
    ├─ supabase.from('profiles') → lib/supabase.ts
    └─ saveSession() → lib/session.ts

app/setup-profile.tsx
    ├─ supabase.from('profiles').insert()
    ├─ supabase.from('volunteers').insert()
    └─ saveSession() → lib/session.ts

contexts/AuthContext.tsx
    ├─ getSession() → lib/session.ts
    ├─ clearSession() → lib/session.ts
    └─ supabase.from('profiles').select()
```

## Security Considerations

```
┌─────────────────────────────────────────────────────────────┐
│                     SECURITY LAYERS                         │
└─────────────────────────────────────────────────────────────┘

1. OTP Verification (2Factor.in)
   └─ Phone ownership verified

2. Session Expiry (24 hours)
   └─ Automatic logout

3. Database RLS (Supabase)
   └─ Row-level permissions (currently: anon = full access)

4. No Sensitive Data in localStorage
   └─ Only: phone, userId, role, timestamp

5. Profile Re-loaded from DB
   └─ Fresh data on each refresh

Future Enhancements:
- Add JWT tokens
- Restrict RLS to user's own data
- Implement refresh tokens
- Add device fingerprinting
```

## Error Handling Flow

```
┌─────────────────────────────────────────────────────────────┐
│                     ERROR SCENARIOS                         │
└─────────────────────────────────────────────────────────────┘

Error: Profile insert fails
├─ Check: RLS policies applied?
├─ Check: Migration ran successfully?
├─ Check: Phone unique constraint?
└─ Console: Detailed error logged

Error: Session not persisting
├─ Check: localStorage enabled?
├─ Check: saveSession() called?
├─ DevTools: Verify localStorage data
└─ Console: "✓ Session saved" logged?

Error: Auto-login not working
├─ Check: getSession() returns data?
├─ Check: userId matches database?
├─ Check: Profile exists in DB?
└─ Console: "Profile loaded" logged?

Error: Permission denied
├─ Check: Migration applied?
├─ Check: RLS policies created?
├─ Check: Using anon role?
└─ Error: "apply migration" message shown
```

---

**Legend:**
- ✓ = Working/Completed
- ✗ = Broken/Failed
- ─▶ = Data flow direction
- ├─ = Component/Step
- └─ = Final step/Result
