export const Colors = {
  primary: '#2E7D32',
  background: '#F9FAF7',
  secondary: '#4A90E2',
  success: '#66BB6A',
  sos: '#D32F2F',
  warning: '#F9A825',
  textDark: '#212121',
  textSecondary: '#616161',
  white: '#FFFFFF',
  border: '#E0E0E0',
  lightGray: '#F5F5F5',
};
