import { Tabs, useRouter } from 'expo-router';
import { Hop as Home, FileText, User } from 'lucide-react-native';
import { Colors } from '@/constants/Colors';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { useEffect } from 'react';

export default function VolunteerLayout() {
  const { t } = useLanguage();
  const { phoneSession, isReady, logoutKey } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!isReady) return;

    if (!phoneSession || phoneSession.role !== 'volunteer') {
      router.replace('/');
    }
  }, [phoneSession, isReady, logoutKey, router]);

  if (!isReady) {
    return null;
  }

  if (!phoneSession || phoneSession.role !== 'volunteer') {
    router.replace('/');
    return null;
  }

  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: Colors.primary,
        tabBarInactiveTintColor: Colors.textSecondary,
        tabBarStyle: {
          height: 70,
          paddingBottom: 10,
          paddingTop: 10,
          backgroundColor: Colors.white,
        },
        tabBarLabelStyle: {
          fontSize: 14,
          fontWeight: '600',
        },
        lazy: true,
        sceneStyle: { backgroundColor: Colors.background },
      }}>
      <Tabs.Screen
        name="home"
        options={{
          title: t.home,
          tabBarIcon: ({ size, color }) => <Home size={size} color={color} />,
        }}
      />
      <Tabs.Screen
        name="requests"
        options={{
          title: t.requests,
          tabBarIcon: ({ size, color }) => (
            <FileText size={size} color={color} />
          ),
        }}
      />
      <Tabs.Screen
        name="profile"
        options={{
          title: t.profile,
          tabBarIcon: ({ size, color }) => <User size={size} color={color} />,
        }}
      />
    </Tabs>
  );
}
