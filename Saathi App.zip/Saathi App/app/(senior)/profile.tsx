import React from 'react';
import { View, Text, StyleSheet, ScrollView, Alert } from 'react-native';
import { useRouter } from 'expo-router';
import { Colors } from '@/constants/Colors';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/Button';
import { Card } from '@/components/Card';
import { User, MapPin, Phone, Languages } from 'lucide-react-native';

export default function ProfileScreen() {
  const { t, language, setLanguage } = useLanguage();
  const { profile, signOut } = useAuth();
  const router = useRouter();

  const handleLogout = () => {
    Alert.alert(
      t.logout,
      'Are you sure you want to logout?',
      [
        { text: t.cancel, style: 'cancel' },
        {
          text: t.logout,
          style: 'destructive',
          onPress: async () => {
            await signOut();
            router.replace('/');
          },
        },
      ],
      { cancelable: true }
    );
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>{t.profile}</Text>
      </View>

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.content}>
        <Card style={styles.profileCard}>
          <View style={styles.avatarContainer}>
            <View style={styles.avatar}>
              <User size={48} color={Colors.primary} />
            </View>
          </View>
          <Text style={styles.name}>{profile?.full_name}</Text>
          <Text style={styles.role}>{t.needHelp}</Text>
        </Card>

        <Card style={styles.infoCard}>
          <View style={styles.infoRow}>
            <Phone size={20} color={Colors.textSecondary} />
            <Text style={styles.infoLabel}>{t.phoneNumber}:</Text>
            <Text style={styles.infoValue}>{profile?.phone}</Text>
          </View>
          {profile?.whatsapp_number && (
            <View style={styles.infoRow}>
              <Phone size={20} color={Colors.textSecondary} />
              <Text style={styles.infoLabel}>{t.whatsappNumber}:</Text>
              <Text style={styles.infoValue}>{profile.whatsapp_number}</Text>
            </View>
          )}
          <View style={styles.infoRow}>
            <MapPin size={20} color={Colors.textSecondary} />
            <Text style={styles.infoLabel}>{t.area}:</Text>
            <Text style={styles.infoValue}>{profile?.area}</Text>
          </View>
          <View style={styles.infoRow}>
            <MapPin size={20} color={Colors.textSecondary} />
            <Text style={styles.infoLabel}>{t.pinCode}:</Text>
            <Text style={styles.infoValue}>{profile?.pin_code}</Text>
          </View>
        </Card>

        <Card style={styles.languageCard}>
          <View style={styles.languageHeader}>
            <Languages size={24} color={Colors.textDark} />
            <Text style={styles.languageTitle}>Language / भाषा</Text>
          </View>
          <View style={styles.languageButtons}>
            <Button
              title="English"
              onPress={() => setLanguage('en')}
              variant={language === 'en' ? 'primary' : 'outline'}
              size="medium"
              style={styles.languageButton}
            />
            <Button
              title="हिंदी"
              onPress={() => setLanguage('hi')}
              variant={language === 'hi' ? 'primary' : 'outline'}
              size="medium"
              style={styles.languageButton}
            />
          </View>
        </Card>

        <Button
          title={t.safetyGuidelines}
          onPress={() => router.push('/safety')}
          variant="secondary"
          size="medium"
        />

        <View style={styles.spacer} />

        <Button
          title={t.logout}
          onPress={handleLogout}
          variant="outline"
          size="medium"
        />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  header: {
    backgroundColor: Colors.primary,
    paddingTop: 50,
    paddingBottom: 20,
    paddingHorizontal: 24,
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: '700',
    color: Colors.white,
  },
  scrollView: {
    flex: 1,
  },
  content: {
    padding: 24,
  },
  profileCard: {
    alignItems: 'center',
    marginBottom: 20,
  },
  avatarContainer: {
    marginBottom: 16,
  },
  avatar: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: Colors.lightGray,
    justifyContent: 'center',
    alignItems: 'center',
  },
  name: {
    fontSize: 28,
    fontWeight: '700',
    color: Colors.textDark,
    marginBottom: 4,
  },
  role: {
    fontSize: 18,
    color: Colors.textSecondary,
  },
  infoCard: {
    marginBottom: 20,
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  infoLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: Colors.textSecondary,
    marginLeft: 12,
    marginRight: 8,
  },
  infoValue: {
    fontSize: 16,
    color: Colors.textDark,
  },
  languageCard: {
    marginBottom: 20,
  },
  languageHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  languageTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: Colors.textDark,
    marginLeft: 12,
  },
  languageButtons: {
    flexDirection: 'row',
    gap: 12,
  },
  languageButton: {
    flex: 1,
  },
  spacer: {
    height: 20,
  },
});
