/*
  # Fix Phone-Based Authentication RLS

  ## Changes
  1. Remove auth.users FK constraint from profiles table
  2. Update RLS policies to work without Supabase auth
  3. Allow anon role access for phone-based authentication
  4. Use phone number as authentication mechanism

  ## Security
  - Profiles table uses phone-based authentication
  - RLS policies allow anon role access
  - Phone uniqueness enforced
*/

-- Drop existing foreign key constraint from profiles
ALTER TABLE profiles DROP CONSTRAINT IF EXISTS profiles_id_fkey;

-- Drop existing RLS policies
DROP POLICY IF EXISTS "Users can view all profiles" ON profiles;
DROP POLICY IF EXISTS "Users can update own profile" ON profiles;
DROP POLICY IF EXISTS "Users can insert own profile" ON profiles;

DROP POLICY IF EXISTS "Anyone can view active volunteers" ON volunteers;
DROP POLICY IF EXISTS "Volunteers can update own profile" ON volunteers;
DROP POLICY IF EXISTS "Users can insert volunteer profile" ON volunteers;

DROP POLICY IF EXISTS "Seniors can view own requests" ON help_requests;
DROP POLICY IF EXISTS "Volunteers can view requests in their area" ON help_requests;
DROP POLICY IF EXISTS "Seniors can create help requests" ON help_requests;
DROP POLICY IF EXISTS "Seniors can update own requests" ON help_requests;
DROP POLICY IF EXISTS "Volunteers can update assigned requests" ON help_requests;

DROP POLICY IF EXISTS "Users can view own SOS contacts" ON sos_contacts;
DROP POLICY IF EXISTS "Users can create own SOS contacts" ON sos_contacts;
DROP POLICY IF EXISTS "Users can update own SOS contacts" ON sos_contacts;
DROP POLICY IF EXISTS "Users can delete own SOS contacts" ON sos_contacts;

-- Create new RLS policies for phone-based auth (anon role access)

-- Profiles: Allow anon to read, insert, and update
CREATE POLICY "Public can view profiles"
  ON profiles FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Public can insert profile"
  ON profiles FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Public can update profiles"
  ON profiles FOR UPDATE
  TO anon, authenticated
  USING (true)
  WITH CHECK (true);

-- Volunteers: Allow public read and write
CREATE POLICY "Public can view volunteers"
  ON volunteers FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Public can insert volunteer profile"
  ON volunteers FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Public can update volunteer profile"
  ON volunteers FOR UPDATE
  TO anon, authenticated
  USING (true)
  WITH CHECK (true);

-- Help Requests: Allow public read and write
CREATE POLICY "Public can view help requests"
  ON help_requests FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Public can create help requests"
  ON help_requests FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Public can update help requests"
  ON help_requests FOR UPDATE
  TO anon, authenticated
  USING (true)
  WITH CHECK (true);

-- SOS Contacts: Allow public read and write
CREATE POLICY "Public can view SOS contacts"
  ON sos_contacts FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Public can create SOS contacts"
  ON sos_contacts FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Public can update SOS contacts"
  ON sos_contacts FOR UPDATE
  TO anon, authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Public can delete SOS contacts"
  ON sos_contacts FOR DELETE
  TO anon, authenticated
  USING (true);

-- Add unique constraint on phone number to prevent duplicates
CREATE UNIQUE INDEX IF NOT EXISTS idx_profiles_phone_unique ON profiles(phone);
