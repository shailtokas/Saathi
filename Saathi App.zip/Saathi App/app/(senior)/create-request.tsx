import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Alert,
  KeyboardAvoidingView,
  Platform,
  TouchableOpacity,
} from 'react-native';
import { useRouter } from 'expo-router';
import { Colors } from '@/constants/Colors';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/Button';
import { Input } from '@/components/Input';
import { Card } from '@/components/Card';
import { supabase } from '@/lib/supabase';
import { ChevronLeft } from 'lucide-react-native';

export default function CreateRequestScreen() {
  const { t } = useLanguage();
  const router = useRouter();
  const { profile } = useAuth();

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('');
  const [urgency, setUrgency] = useState('medium');
  const [loading, setLoading] = useState(false);

  const categories = ['medicine', 'doctor', 'grocery', 'talk'];
  const urgencyLevels = ['low', 'medium', 'high'];

  const createRequest = async () => {
    if (!title || !description || !category) {
      Alert.alert('Error', 'Please fill in all required fields');
      return;
    }

    if (!profile) {
      Alert.alert('Error', 'Profile not found');
      return;
    }

    setLoading(true);
    try {
      console.log('=== CREATING HELP REQUEST ===');
      console.log('Senior ID:', profile.id);
      console.log('Title:', title);
      console.log('Category:', category);

      const requestData = {
        senior_id: profile.id,
        title,
        description,
        category,
        urgency,
        area: profile.area,
        pin_code: profile.pin_code,
        status: 'open',
      };

      console.log('Request data:', JSON.stringify(requestData, null, 2));

      const { error } = await supabase.from('help_requests').insert(requestData as any);

      console.log('Request insert result:', { error });

      if (error) {
        console.error('Request insert error:', error);
        throw error;
      }

      console.log('✓ Help request created successfully');
      Alert.alert('Success', 'Your request has been created');
      router.back();
    } catch (error: any) {
      console.error('Create request error:', error);

      let errorMessage = error.message;

      if (error.message?.includes('permission denied') || error.message?.includes('policy')) {
        errorMessage = 'Database permissions error. Please apply the migration in MIGRATION_INSTRUCTIONS.md';
      }

      Alert.alert('Error', errorMessage);
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={{ flex: 1 }}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
      <View style={styles.container}>
        <View style={styles.header}>
          <TouchableOpacity
            style={styles.backButton}
            onPress={() => router.back()}>
            <ChevronLeft size={28} color={Colors.white} />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>{t.createRequest}</Text>
        </View>

        <ScrollView
          style={styles.scrollView}
          contentContainerStyle={styles.content}>
          <Input
            label={t.title + ' *'}
            value={title}
            onChangeText={setTitle}
            placeholder="Brief description of help needed"
          />

          <Input
            label={t.description + ' *'}
            value={description}
            onChangeText={setDescription}
            placeholder="Provide more details"
            multiline
            numberOfLines={4}
          />

          <View style={styles.section}>
            <Text style={styles.sectionLabel}>{t.category + ' *'}</Text>
            <View style={styles.optionGrid}>
              {categories.map((cat) => (
                <TouchableOpacity
                  key={cat}
                  style={[
                    styles.optionButton,
                    category === cat && styles.optionButtonSelected,
                  ]}
                  onPress={() => setCategory(cat)}>
                  <Text
                    style={[
                      styles.optionText,
                      category === cat && styles.optionTextSelected,
                    ]}>
                    {t.helpCategories[cat as keyof typeof t.helpCategories]}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>

          <View style={styles.section}>
            <Text style={styles.sectionLabel}>{t.urgencyLevel}</Text>
            <View style={styles.optionGrid}>
              {urgencyLevels.map((level) => (
                <TouchableOpacity
                  key={level}
                  style={[
                    styles.optionButton,
                    urgency === level && styles.optionButtonSelected,
                  ]}
                  onPress={() => setUrgency(level)}>
                  <Text
                    style={[
                      styles.optionText,
                      urgency === level && styles.optionTextSelected,
                    ]}>
                    {t.urgency[level as keyof typeof t.urgency]}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>

          <Card style={styles.infoCard}>
            <Text style={styles.infoText}>{t.contactBeforeHelp}</Text>
          </Card>

          <Button
            title={t.submit}
            onPress={createRequest}
            loading={loading}
            variant="primary"
          />
        </ScrollView>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  header: {
    backgroundColor: Colors.primary,
    paddingTop: 50,
    paddingBottom: 20,
    paddingHorizontal: 16,
    flexDirection: 'row',
    alignItems: 'center',
  },
  backButton: {
    marginRight: 16,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: '700',
    color: Colors.white,
  },
  scrollView: {
    flex: 1,
  },
  content: {
    padding: 24,
  },
  section: {
    marginBottom: 24,
  },
  sectionLabel: {
    fontSize: 18,
    fontWeight: '600',
    color: Colors.textDark,
    marginBottom: 12,
  },
  optionGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  optionButton: {
    flex: 1,
    minWidth: '45%',
    backgroundColor: Colors.white,
    borderWidth: 2,
    borderColor: Colors.border,
    borderRadius: 12,
    paddingVertical: 16,
    paddingHorizontal: 20,
    alignItems: 'center',
  },
  optionButtonSelected: {
    backgroundColor: Colors.primary,
    borderColor: Colors.primary,
  },
  optionText: {
    fontSize: 18,
    fontWeight: '600',
    color: Colors.textDark,
  },
  optionTextSelected: {
    color: Colors.white,
  },
  infoCard: {
    marginBottom: 24,
    backgroundColor: Colors.lightGray,
  },
  infoText: {
    fontSize: 16,
    color: Colors.textSecondary,
    lineHeight: 24,
  },
});
