export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[];

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string;
          phone: string;
          full_name: string;
          role: 'senior' | 'volunteer';
          area: string;
          pin_code: string;
          whatsapp_number: string | null;
          profile_photo_url: string | null;
          language_preference: 'en' | 'hi';
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id: string;
          phone: string;
          full_name: string;
          role: 'senior' | 'volunteer';
          area: string;
          pin_code: string;
          whatsapp_number?: string | null;
          profile_photo_url?: string | null;
          language_preference?: 'en' | 'hi';
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          phone?: string;
          full_name?: string;
          role?: 'senior' | 'volunteer';
          area?: string;
          pin_code?: string;
          whatsapp_number?: string | null;
          profile_photo_url?: string | null;
          language_preference?: 'en' | 'hi';
          created_at?: string;
          updated_at?: string;
        };
      };
      volunteers: {
        Row: {
          id: string;
          user_id: string;
          is_verified: boolean;
          help_description: string | null;
          available_categories: string[];
          is_active: boolean;
          total_helps: number;
          created_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          is_verified?: boolean;
          help_description?: string | null;
          available_categories?: string[];
          is_active?: boolean;
          total_helps?: number;
          created_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          is_verified?: boolean;
          help_description?: string | null;
          available_categories?: string[];
          is_active?: boolean;
          total_helps?: number;
          created_at?: string;
        };
      };
      help_requests: {
        Row: {
          id: string;
          senior_id: string;
          volunteer_id: string | null;
          title: string;
          description: string;
          category: 'medicine' | 'doctor' | 'grocery' | 'talk';
          area: string;
          pin_code: string;
          urgency: 'low' | 'medium' | 'high';
          status: 'open' | 'in_progress' | 'completed';
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          senior_id: string;
          volunteer_id?: string | null;
          title: string;
          description: string;
          category: 'medicine' | 'doctor' | 'grocery' | 'talk';
          area: string;
          pin_code: string;
          urgency?: 'low' | 'medium' | 'high';
          status?: 'open' | 'in_progress' | 'completed';
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          senior_id?: string;
          volunteer_id?: string | null;
          title?: string;
          description?: string;
          category?: 'medicine' | 'doctor' | 'grocery' | 'talk';
          area?: string;
          pin_code?: string;
          urgency?: 'low' | 'medium' | 'high';
          status?: 'open' | 'in_progress' | 'completed';
          created_at?: string;
          updated_at?: string;
        };
      };
      sos_contacts: {
        Row: {
          id: string;
          user_id: string;
          contact_name: string;
          contact_phone: string;
          contact_whatsapp: string | null;
          is_primary: boolean;
          created_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          contact_name: string;
          contact_phone: string;
          contact_whatsapp?: string | null;
          is_primary?: boolean;
          created_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          contact_name?: string;
          contact_phone?: string;
          contact_whatsapp?: string | null;
          is_primary?: boolean;
          created_at?: string;
        };
      };
    };
  };
}
