# Redirect Flicker and Auto-Home Bug Fix

## Problems Fixed

1. **Race Condition**: When login or profile setup saved the session to localStorage, it immediately triggered AuthContext state updates, causing the landing page to auto-redirect BEFORE the manual navigation could complete
2. **Double Navigation**: Both the originating screen AND the landing page tried to navigate simultaneously
3. **Flicker**: Loading spinner would briefly appear during the race condition
4. **Premature Navigation**: Landing page would redirect even during state transitions

## Solution Implemented

### 1. Landing Page (index.tsx)
- Added `useSegments()` to check if already in auth group
- Prevents redirect if already navigating to `(senior)` or `(volunteer)` routes
- Uses `requestAnimationFrame()` to defer redirect until next frame
- Returns `null` instead of loading spinner to prevent flicker
- Resets redirect flag when session is cleared

### 2. Login Flow (login.tsx)
- **Navigate first, save session after**: Moves `router.replace()` before `saveSession()`
- Uses `requestAnimationFrame()` to defer session save until after navigation starts
- Eliminates race condition by ensuring navigation happens before state update

### 3. Profile Setup Flow (setup-profile.tsx)
- Same pattern as login: navigate first, save session after
- Prepares session data early but saves it after navigation
- Uses `requestAnimationFrame()` for deferred session save

### 4. Role-Specific Layouts
- Added auth guards to `(senior)/_layout.tsx` and `(volunteer)/_layout.tsx`
- Checks session and role on mount
- Redirects to landing page if no session or wrong role
- Returns `null` during check to prevent tab bar from flashing

## Key Technical Details

### Session Save Timing
```typescript
// OLD (causes race condition)
saveSession(data);
router.replace('/home');

// NEW (prevents race condition)
router.replace('/home');
requestAnimationFrame(() => {
  saveSession(data);
});
```

### Landing Page Redirect Logic
```typescript
// Only redirect if:
// 1. Have session
// 2. Haven't redirected yet
// 3. Not already in auth group
const inAuthGroup = segments[0] === '(senior)' || segments[0] === '(volunteer)';

if (phoneSession && !hasRedirected.current && !inAuthGroup) {
  hasRedirected.current = true;
  requestAnimationFrame(() => {
    router.replace('/(senior)/home'); // or volunteer
  });
}
```

## Behavior After Fix

### Login/Signup Flow
1. User enters OTP and verifies
2. Navigation starts immediately (no delay)
3. Session saves in next frame (doesn't trigger extra renders)
4. Landing page doesn't interfere (already in auth group)
5. Home screen loads smoothly

### Logout Flow
1. User clicks logout
2. Session cleared from localStorage
3. State updated (profile and phoneSession set to null)
4. `router.dismissAll()` clears navigation stack
5. `router.replace('/')` navigates to landing page
6. Landing page resets redirect flag
7. "Need Help" / "Want to Help" buttons work correctly

### Session Persistence
1. User refreshes page or returns later
2. AuthContext loads session from localStorage
3. Landing page checks session and segments
4. If not already in auth group, redirects to appropriate home
5. No flicker, clean transition

## No Full Reload Required

All transitions happen through:
- React state management (AuthContext)
- Expo Router navigation (router.replace)
- LocalStorage for persistence

No `window.location.reload()` or similar hacks needed.
