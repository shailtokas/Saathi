import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Alert,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { Colors } from '@/constants/Colors';
import { useLanguage } from '@/contexts/LanguageContext';
import { Button } from '@/components/Button';
import { Input } from '@/components/Input';
import { send2FactorOTP, verify2FactorOTP } from '@/lib/2factor';
import { supabase } from '@/lib/supabase';
import { saveSession } from '@/lib/session';

export default function LoginScreen() {
  const { t } = useLanguage();
  const router = useRouter();
  const { role } = useLocalSearchParams<{ role: string }>();

  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState('');
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [otpSent, setOtpSent] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  useEffect(() => {
    if (errorMessage) {
      setErrorMessage(null);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [phone, otp]);

  const sendOTP = async () => {
    if (!phone || phone.length < 10) {
      setErrorMessage('Please enter a valid 10-digit phone number');
      return;
    }

    setLoading(true);
    setErrorMessage(null);

    try {
      console.log('Sending OTP via 2Factor to:', `+91${phone}`);
      const result = await send2FactorOTP(`91${phone}`);

      if (result.success && result.sessionId) {
        setSessionId(result.sessionId);
        setOtpSent(true);
        Alert.alert('Success', 'OTP sent to +91' + phone + '. Please check your SMS.');
      } else {
        setErrorMessage(result.error || 'Failed to send OTP');
        Alert.alert('Error', result.error || 'Failed to send OTP. Please try again.');
      }
    } catch (error: any) {
      console.error('Send OTP exception:', error);
      const errorMsg = error.message || 'Failed to send OTP. Please try again.';
      setErrorMessage(errorMsg);
      Alert.alert('Error', errorMsg);
    } finally {
      setLoading(false);
    }
  };

  const verifyOTP = async () => {
    if (!otp || otp.length !== 6) {
      setErrorMessage('Please enter a valid 6-digit OTP');
      return;
    }

    if (!sessionId) {
      setErrorMessage('Session expired. Please request a new OTP.');
      return;
    }

    setLoading(true);
    setErrorMessage(null);

    try {
      console.log('Verifying OTP with 2Factor');
      const result = await verify2FactorOTP(sessionId, otp);

      if (result.success) {
        console.log('OTP verified successfully');

        // Check if user exists in profiles table
        const phoneWithCode = `+91${phone}`;
        const { data: existingProfile } = await supabase
          .from('profiles')
          .select('*')
          .eq('phone', phoneWithCode)
          .maybeSingle();

        if (existingProfile) {
          // User exists, navigate first then save session
          console.log('Existing user found:', (existingProfile as any).role);

          const sessionData = {
            phone: phoneWithCode,
            userId: (existingProfile as any).id,
            role: (existingProfile as any).role,
            timestamp: Date.now(),
          };

          // Route based on existing profile
          if ((existingProfile as any).role === 'senior') {
            router.replace('/(senior)/home');
          } else {
            router.replace('/(volunteer)/home');
          }

          // Save session after navigation starts to avoid race condition
          requestAnimationFrame(() => {
            saveSession(sessionData);
            console.log('✓ Session saved for existing user');
          });
        } else {
          // New user, go to profile setup
          console.log('New user, redirecting to profile setup');
          router.replace(`/setup-profile?role=${role}&phone=${phoneWithCode}`);
        }
      } else {
        setErrorMessage(result.error || 'Invalid OTP');
        Alert.alert('Error', result.error || 'Invalid OTP. Please check and try again.');
      }
    } catch (error: any) {
      console.error('Verify OTP exception:', error);
      const errorMsg = error.message || 'Failed to verify OTP. Please try again.';
      setErrorMessage(errorMsg);
      Alert.alert('Error', errorMsg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={{ flex: 1 }}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}>
        <Text style={styles.title}>{t.login}</Text>
        <Text style={styles.subtitle}>
          {role === 'senior' ? t.needHelp : t.wantToHelp}
        </Text>

        {errorMessage && (
          <View style={styles.errorContainer}>
            <Text style={styles.errorText}>{errorMessage}</Text>
          </View>
        )}

        {!otpSent ? (
          <>
            <Input
              label={t.phoneNumber + ' (+91)'}
              value={phone}
              onChangeText={setPhone}
              keyboardType="phone-pad"
              placeholder="9876543210"
              maxLength={10}
            />
            <Button
              title={t.sendOTP}
              onPress={sendOTP}
              loading={loading}
              variant="primary"
            />
          </>
        ) : (
          <>
            <Input
              label={t.enterOTP}
              value={otp}
              onChangeText={setOtp}
              keyboardType="number-pad"
              placeholder="123456"
              maxLength={6}
            />
            <Button
              title={t.verify}
              onPress={verifyOTP}
              loading={loading}
              variant="primary"
            />
            <View style={styles.resendContainer}>
              <Button
                title={t.resendOTP}
                onPress={() => {
                  setOtpSent(false);
                  setOtp('');
                  setSessionId(null);
                }}
                variant="outline"
                size="medium"
              />
            </View>
          </>
        )}

        <View style={styles.backContainer}>
          <Button
            title={t.cancel}
            onPress={() => router.back()}
            variant="outline"
            size="medium"
          />
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  content: {
    flexGrow: 1,
    padding: 24,
    justifyContent: 'center',
  },
  title: {
    fontSize: 36,
    fontWeight: '800',
    color: Colors.textDark,
    marginBottom: 8,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 20,
    color: Colors.textSecondary,
    textAlign: 'center',
    marginBottom: 40,
  },
  errorContainer: {
    backgroundColor: '#FFEBEE',
    padding: 16,
    borderRadius: 8,
    marginBottom: 20,
    borderLeftWidth: 4,
    borderLeftColor: Colors.sos,
  },
  errorText: {
    fontSize: 16,
    color: '#C62828',
    lineHeight: 22,
  },
  resendContainer: {
    marginTop: 20,
  },
  backContainer: {
    marginTop: 20,
  },
});
