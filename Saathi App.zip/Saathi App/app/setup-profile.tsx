import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Alert,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { Colors } from '@/constants/Colors';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/Button';
import { Input } from '@/components/Input';
import { supabase } from '@/lib/supabase';
import { saveSession } from '@/lib/session';

export default function SetupProfileScreen() {
  const { t } = useLanguage();
  const router = useRouter();
  const { role, phone } = useLocalSearchParams<{ role?: string; phone?: string }>();
  const { refreshProfile } = useAuth();

  const [fullName, setFullName] = useState('');
  const [area, setArea] = useState('');
  const [pinCode, setPinCode] = useState('');
  const [whatsappNumber, setWhatsappNumber] = useState('');
  const [helpDescription, setHelpDescription] = useState('');
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);

  const categories = ['medicine', 'doctor', 'grocery', 'talk'];

  const toggleCategory = (category: string) => {
    if (selectedCategories.includes(category)) {
      setSelectedCategories(selectedCategories.filter((c) => c !== category));
    } else {
      setSelectedCategories([...selectedCategories, category]);
    }
  };

  const saveProfile = async () => {
    if (!fullName || !area || !pinCode) {
      Alert.alert('Error', 'Please fill in all required fields');
      return;
    }

    if (!phone) {
      Alert.alert('Error', 'Phone number missing');
      return;
    }

    setLoading(true);
    try {
      console.log('=== SAVING PROFILE ===');
      console.log('Phone:', phone);
      console.log('Role:', role);
      console.log('Full Name:', fullName);

      // Generate a UUID for the new user
      const userId = crypto.randomUUID();
      console.log('Generated User ID:', userId);

      const profileData = {
        id: userId,
        phone: phone,
        full_name: fullName,
        role: (role as 'senior' | 'volunteer') || 'senior',
        area,
        pin_code: pinCode,
        whatsapp_number: whatsappNumber || null,
      };

      console.log('Profile data to insert:', JSON.stringify(profileData, null, 2));

      const { data: insertedProfile, error: profileError } = await supabase
        .from('profiles')
        .insert(profileData as any)
        .select();

      console.log('Profile insert result:', { data: insertedProfile, error: profileError });

      if (profileError) {
        console.error('=== PROFILE INSERT ERROR ===');
        console.error('Error message:', profileError.message);
        console.error('Error code:', profileError.code);
        console.error('Error details:', profileError.details);
        console.error('Error hint:', profileError.hint);
        console.error('Full error object:', JSON.stringify(profileError, null, 2));
        throw profileError;
      }

      console.log('✓ Profile saved successfully');

      // Prepare session data but don't save yet
      const sessionData = {
        phone: phone,
        userId: userId,
        role: (role as 'senior' | 'volunteer') || 'senior',
        timestamp: Date.now(),
      };

      if (role === 'volunteer') {
        console.log('Inserting volunteer profile...');

        const volunteerData = {
          user_id: userId,
          help_description: helpDescription || null,
          available_categories: selectedCategories,
          is_active: true,
        };

        console.log('Volunteer data:', JSON.stringify(volunteerData, null, 2));

        const { error: volunteerError } = await supabase
          .from('volunteers')
          .insert(volunteerData as any);

        console.log('Volunteer insert result:', { error: volunteerError });

        if (volunteerError) {
          console.error('Volunteer insert error:', volunteerError);
          throw volunteerError;
        }

        console.log('✓ Volunteer profile saved successfully');
      }

      // No need to refresh profile since we don't use Supabase auth
      console.log('=== PROFILE SETUP COMPLETE ===');
      console.log('Redirecting to home screen...');

      // Navigate first
      if (role === 'senior') {
        router.replace('/(senior)/home');
      } else {
        router.replace('/(volunteer)/home');
      }

      // Save session after navigation starts to avoid race condition
      requestAnimationFrame(() => {
        saveSession(sessionData);
        console.log('✓ Session saved for new user');
      });
    } catch (error: any) {
      console.error('Profile save error:', error);

      let errorMessage = error.message;

      if (error.message?.includes('violates foreign key constraint')) {
        errorMessage = 'Database configuration error. Please apply the migration in MIGRATION_INSTRUCTIONS.md';
      } else if (error.message?.includes('permission denied') || error.message?.includes('policy')) {
        errorMessage = 'Database permissions error. Please apply the migration in MIGRATION_INSTRUCTIONS.md';
      } else if (error.message?.includes('duplicate key')) {
        errorMessage = 'This phone number is already registered. Please use login instead.';
      }

      Alert.alert('Error', errorMessage);
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={{ flex: 1 }}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}>
        <Text style={styles.title}>{t.profile}</Text>
        <Text style={styles.subtitle}>
          {role === 'senior' ? t.needHelp : t.wantToHelp}
        </Text>

        <Input
          label={t.fullName + ' *'}
          value={fullName}
          onChangeText={setFullName}
          placeholder="Enter your full name"
        />

        <Input
          label={t.area + ' *'}
          value={area}
          onChangeText={setArea}
          placeholder="Enter your area/locality"
        />

        <Input
          label={t.pinCode + ' *'}
          value={pinCode}
          onChangeText={setPinCode}
          keyboardType="number-pad"
          placeholder="Enter pin code"
          maxLength={6}
        />

        <Input
          label={t.whatsappNumber}
          value={whatsappNumber}
          onChangeText={setWhatsappNumber}
          keyboardType="phone-pad"
          placeholder="9876543210"
          maxLength={10}
        />

        {role === 'volunteer' && (
          <>
            <Input
              label={t.helpDescription}
              value={helpDescription}
              onChangeText={setHelpDescription}
              placeholder="Describe how you can help"
              multiline
              numberOfLines={3}
            />

            <View style={styles.categoriesContainer}>
              <Text style={styles.categoryLabel}>{t.availableFor}</Text>
              <View style={styles.categoryButtons}>
                {categories.map((cat) => (
                  <Button
                    key={cat}
                    title={
                      t.helpCategories[cat as keyof typeof t.helpCategories]
                    }
                    onPress={() => toggleCategory(cat)}
                    variant={
                      selectedCategories.includes(cat) ? 'primary' : 'outline'
                    }
                    size="medium"
                    style={styles.categoryButton}
                  />
                ))}
              </View>
            </View>
          </>
        )}

        <Button
          title={t.saveProfile}
          onPress={saveProfile}
          loading={loading}
          variant="primary"
        />
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  content: {
    flexGrow: 1,
    padding: 24,
    paddingTop: 60,
  },
  title: {
    fontSize: 36,
    fontWeight: '800',
    color: Colors.textDark,
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 20,
    color: Colors.textSecondary,
    marginBottom: 32,
  },
  categoriesContainer: {
    marginBottom: 24,
  },
  categoryLabel: {
    fontSize: 18,
    fontWeight: '600',
    color: Colors.textDark,
    marginBottom: 12,
  },
  categoryButtons: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  categoryButton: {
    flex: 0,
    minWidth: '45%',
  },
});
