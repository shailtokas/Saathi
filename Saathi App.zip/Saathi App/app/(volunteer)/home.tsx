import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  ActivityIndicator,
  RefreshControl,
  TouchableOpacity,
  Linking,
} from 'react-native';
import { Colors } from '@/constants/Colors';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { Card } from '@/components/Card';
import { Button } from '@/components/Button';
import { supabase } from '@/lib/supabase';
import { Heart, Phone, MessageCircle } from 'lucide-react-native';

interface HelpRequest {
  id: string;
  title: string;
  description: string;
  category: string;
  urgency: string;
  status: string;
  area: string;
  created_at: string;
  profiles: {
    full_name: string;
    phone: string;
    whatsapp_number: string | null;
  };
}

export default function VolunteerHomeScreen() {
  const { t } = useLanguage();
  const { profile } = useAuth();
  const [requests, setRequests] = useState<HelpRequest[]>([]);
  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    if (profile?.area) {
      setLoading(true);
      loadRequests();
    }
  }, [profile?.area]);

  const loadRequests = async () => {
    if (!profile) return;

    try {
      const { data, error } = await supabase
        .from('help_requests')
        .select(
          `
          id,
          title,
          description,
          category,
          urgency,
          status,
          area,
          created_at,
          profiles!inner (
            full_name,
            phone,
            whatsapp_number
          )
        `
        )
        .eq('status', 'open')
        // remove this filter
        .order('created_at', { ascending: false })
        .limit(10);

      if (error) throw error;

      setRequests(data || []);
    } catch (error) {
      console.error('Error loading requests:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const onRefresh = () => {
    setRefreshing(true);
    loadRequests();
  };

  const handleCall = (phone: string) => {
    Linking.openURL(`tel:${phone}`);
  };

  const handleWhatsApp = (phone: string) => {
    const message = encodeURIComponent(t.contactBeforeHelp);
    Linking.openURL(`https://wa.me/${phone}?text=${message}`);
  };

  const getUrgencyColor = (urgency: string) => {
    switch (urgency) {
      case 'high':
        return Colors.sos;
      case 'medium':
        return Colors.warning;
      case 'low':
        return Colors.success;
      default:
        return Colors.textSecondary;
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Heart size={32} color={Colors.white} fill={Colors.white} />
        <Text style={styles.greeting}>{t.appName}</Text>
        <Text style={styles.userName}>{profile?.full_name}</Text>
      </View>

      {loading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={Colors.primary} />
        </View>
      ) : (
        <ScrollView
          style={styles.scrollView}
          contentContainerStyle={styles.content}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={onRefresh}
              tintColor={Colors.primary}
            />
          }>
          <Text style={styles.sectionTitle}>
            Help Requests in {profile?.area}
          </Text>

          {requests.length === 0 ? (
            <Card>
              <Text style={styles.emptyText}>
                No open help requests in your area at the moment.
              </Text>
            </Card>
          ) : (
            requests.map((request) => (
              <Card key={request.id} style={styles.requestCard}>
                <View style={styles.requestHeader}>
                  <Text style={styles.requestTitle}>{request.title}</Text>
                  <View
                    style={[
                      styles.urgencyBadge,
                      {
                        backgroundColor: getUrgencyColor(request.urgency),
                      },
                    ]}>
                    <Text style={styles.badgeText}>
                      {t.urgency[request.urgency as keyof typeof t.urgency]}
                    </Text>
                  </View>
                </View>

                <Text style={styles.categoryText}>
                  {
                    t.helpCategories[
                      request.category as keyof typeof t.helpCategories
                    ]
                  }
                </Text>

                <Text style={styles.requestDescription}>
                  {request.description}
                </Text>

                <View style={styles.seniorInfo}>
                  <Text style={styles.seniorName}>
                    {request.profiles.full_name}
                  </Text>
                  <Text style={styles.requestTime}>
                    {new Date(request.created_at).toLocaleDateString()}
                  </Text>
                </View>

                <View style={styles.actions}>
                  <Button
                    title={t.call}
                    onPress={() => handleCall(request.profiles.phone)}
                    variant="primary"
                    size="medium"
                    style={styles.actionButton}
                  />
                  {request.profiles.whatsapp_number && (
                    <Button
                      title={t.whatsapp}
                      onPress={() =>
                        handleWhatsApp(request.profiles.whatsapp_number!)
                      }
                      variant="secondary"
                      size="medium"
                      style={styles.actionButton}
                    />
                  )}
                </View>
              </Card>
            ))
          )}
        </ScrollView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  header: {
    backgroundColor: Colors.primary,
    padding: 24,
    paddingTop: 60,
    paddingBottom: 32,
    alignItems: 'center',
  },
  greeting: {
    fontSize: 24,
    fontWeight: '700',
    color: Colors.white,
    marginTop: 8,
  },
  userName: {
    fontSize: 18,
    color: Colors.white,
    opacity: 0.9,
    marginTop: 4,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  scrollView: {
    flex: 1,
  },
  content: {
    padding: 24,
  },
  sectionTitle: {
    fontSize: 22,
    fontWeight: '700',
    color: Colors.textDark,
    marginBottom: 16,
  },
  emptyText: {
    fontSize: 16,
    color: Colors.textSecondary,
    textAlign: 'center',
    lineHeight: 24,
  },
  requestCard: {
    marginBottom: 16,
  },
  requestHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 8,
  },
  requestTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: Colors.textDark,
    flex: 1,
    marginRight: 12,
  },
  urgencyBadge: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 6,
  },
  badgeText: {
    color: Colors.white,
    fontSize: 14,
    fontWeight: '600',
  },
  categoryText: {
    fontSize: 16,
    color: Colors.primary,
    fontWeight: '600',
    marginBottom: 8,
  },
  requestDescription: {
    fontSize: 16,
    color: Colors.textDark,
    lineHeight: 24,
    marginBottom: 12,
  },
  seniorInfo: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: Colors.border,
    marginBottom: 16,
  },
  seniorName: {
    fontSize: 16,
    fontWeight: '600',
    color: Colors.textDark,
  },
  requestTime: {
    fontSize: 14,
    color: Colors.textSecondary,
  },
  actions: {
    flexDirection: 'row',
    gap: 12,
  },
  actionButton: {
    flex: 1,
  },
});
