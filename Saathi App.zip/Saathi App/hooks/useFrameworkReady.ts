import { useEffect, useState } from 'react';

declare global {
  interface Window {
    frameworkReady?: () => void;
  }
}

export function useFrameworkReady() {
  const [isReady, setIsReady] = useState(true);

  useEffect(() => {
    window.frameworkReady?.();
  }, []);

  return isReady;
}
