import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
} from 'react-native';
import { useRouter } from 'expo-router';
import { Colors } from '@/constants/Colors';
import { useLanguage } from '@/contexts/LanguageContext';
import { Card } from '@/components/Card';
import { ChevronLeft, ShieldCheck, CircleAlert as AlertCircle } from 'lucide-react-native';

export default function SafetyGuidelinesScreen() {
  const { t } = useLanguage();
  const router = useRouter();

  const guidelines = [
    t.safety.point1,
    t.safety.point2,
    t.safety.point3,
    t.safety.point4,
    t.safety.point5,
  ];

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => router.back()}>
          <ChevronLeft size={28} color={Colors.white} />
        </TouchableOpacity>
        <View style={styles.headerContent}>
          <ShieldCheck size={40} color={Colors.white} />
          <Text style={styles.headerTitle}>{t.safety.title}</Text>
        </View>
      </View>

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.content}>
        <Card style={styles.introCard}>
          <Text style={styles.introText}>{t.safety.intro}</Text>
        </Card>

        {guidelines.map((guideline, index) => (
          <Card key={index} style={styles.guidelineCard}>
            <View style={styles.bulletPoint} />
            <Text style={styles.guidelineText}>{guideline}</Text>
          </Card>
        ))}

        <Card style={styles.sosCard}>
          <View style={styles.sosContent}>
            <AlertCircle size={32} color={Colors.sos} />
            <View style={styles.sosTextContainer}>
              <Text style={styles.sosTitle}>Emergency</Text>
              <Text style={styles.sosText}>Call 112 for immediate assistance</Text>
            </View>
          </View>
        </Card>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  header: {
    backgroundColor: Colors.primary,
    paddingTop: 50,
    paddingBottom: 24,
    paddingHorizontal: 16,
  },
  backButton: {
    marginBottom: 16,
  },
  headerContent: {
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: '700',
    color: Colors.white,
    marginTop: 12,
  },
  scrollView: {
    flex: 1,
  },
  content: {
    padding: 24,
    paddingBottom: 32,
  },
  introCard: {
    marginBottom: 32,
    backgroundColor: Colors.secondary,
  },
  introText: {
    fontSize: 18,
    color: Colors.white,
    lineHeight: 28,
    textAlign: 'center',
    fontWeight: '500',
  },
  guidelineCard: {
    marginBottom: 16,
    flexDirection: 'row',
    alignItems: 'flex-start',
    backgroundColor: Colors.white,
    borderLeftWidth: 4,
    borderLeftColor: Colors.primary,
  },
  bulletPoint: {
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: Colors.primary,
    marginRight: 16,
    marginTop: 6,
    flexShrink: 0,
  },
  guidelineText: {
    flex: 1,
    fontSize: 18,
    color: Colors.textDark,
    lineHeight: 28,
    fontWeight: '500',
  },
  sosCard: {
    marginTop: 24,
    backgroundColor: '#FEE',
    borderWidth: 2,
    borderColor: Colors.sos,
  },
  sosContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  sosTextContainer: {
    marginLeft: 16,
    flex: 1,
  },
  sosTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: Colors.sos,
    marginBottom: 4,
  },
  sosText: {
    fontSize: 16,
    color: Colors.textDark,
    fontWeight: '500',
  },
});
