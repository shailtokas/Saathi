/**
 * Session management for phone-based authentication
 * Stores user session info in localStorage for web
 */

const SESSION_KEY = 'race_saathi_session';

export interface UserSession {
  phone: string;
  userId: string;
  role: 'senior' | 'volunteer';
  timestamp: number;
}

let cachedSession: UserSession | null | undefined = undefined;

/**
 * Save user session after successful login/profile creation
 */
export const saveSession = (session: UserSession): void => {
  try {
    cachedSession = session;
    const sessionData = JSON.stringify(session);

    if (typeof window !== 'undefined' && window.localStorage) {
      localStorage.setItem(SESSION_KEY, sessionData);
    }
  } catch (error) {
    console.error('Error saving session:', error);
  }
};

/**
 * Get current user session
 */
export const getSession = (): UserSession | null => {
  if (cachedSession !== undefined) {
    return cachedSession;
  }

  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      const sessionData = localStorage.getItem(SESSION_KEY);

      if (!sessionData) {
        cachedSession = null;
        return null;
      }

      const session: UserSession = JSON.parse(sessionData);

      const now = Date.now();
      const sessionAge = now - session.timestamp;
      const maxAge = 24 * 60 * 60 * 1000;

      if (sessionAge > maxAge) {
        clearSession();
        return null;
      }

      cachedSession = session;
      return session;
    }

    cachedSession = null;
    return null;
  } catch (error) {
    console.error('Error getting session:', error);
    cachedSession = null;
    return null;
  }
};

/**
 * Clear user session (logout)
 */
export const clearSession = (): void => {
  try {
    cachedSession = null;
    if (typeof window !== 'undefined' && window.localStorage) {
      localStorage.removeItem(SESSION_KEY);
      localStorage.clear();
    }
  } catch (error) {
    console.error('Error clearing session:', error);
  }
};

/**
 * Update session (e.g., after profile update)
 */
export const updateSession = (updates: Partial<UserSession>): void => {
  try {
    const currentSession = getSession();

    if (!currentSession) {
      cachedSession = null;
      return;
    }

    const updatedSession: UserSession = {
      ...currentSession,
      ...updates,
      timestamp: Date.now(),
    };

    saveSession(updatedSession);
  } catch (error) {
    console.error('Error updating session:', error);
  }
};
