import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { useRouter } from 'expo-router';
import { Colors } from '@/constants/Colors';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/Button';
import { Card } from '@/components/Card';
import {
  UserPlus,
  FileText,
  ShieldAlert,
  ShieldCheck,
} from 'lucide-react-native';

export default function SeniorHomeScreen() {
  const { t } = useLanguage();
  const { profile } = useAuth();
  const router = useRouter();

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.greeting}>
          {t.appName}
        </Text>
        <Text style={styles.userName}>{profile?.full_name}</Text>
      </View>

      <View style={styles.content}>
        <Card style={styles.quickActions}>
          <Text style={styles.sectionTitle}>{t.needHelp}</Text>
          <Button
            title={t.createRequest}
            onPress={() => router.push('/(senior)/create-request')}
            variant="primary"
            size="large"
          />
          <View style={styles.buttonSpacer} />
          <Button
            title={t.nearbyVolunteers}
            onPress={() => router.push('/(senior)/volunteers')}
            variant="secondary"
            size="large"
          />
        </Card>

        <Card style={styles.infoCard}>
          <View style={styles.infoHeader}>
            <ShieldCheck size={28} color={Colors.primary} />
            <Text style={styles.infoTitle}>{t.safetyGuidelines}</Text>
          </View>
          <Text style={styles.infoText}>{t.contactBeforeHelp}</Text>
          <Button
            title={t.safetyGuidelines}
            onPress={() => router.push('/safety')}
            variant="outline"
            size="medium"
            style={styles.infoButton}
          />
        </Card>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  header: {
    backgroundColor: Colors.primary,
    padding: 24,
    paddingTop: 60,
    paddingBottom: 32,
  },
  greeting: {
    fontSize: 28,
    fontWeight: '700',
    color: Colors.white,
    marginBottom: 4,
  },
  userName: {
    fontSize: 20,
    color: Colors.white,
    opacity: 0.9,
  },
  content: {
    padding: 24,
  },
  quickActions: {
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 24,
    fontWeight: '700',
    color: Colors.textDark,
    marginBottom: 20,
  },
  buttonSpacer: {
    height: 16,
  },
  infoCard: {
    marginBottom: 20,
  },
  infoHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  infoTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: Colors.textDark,
    marginLeft: 12,
  },
  infoText: {
    fontSize: 16,
    color: Colors.textSecondary,
    lineHeight: 24,
    marginBottom: 16,
  },
  infoButton: {
    marginTop: 8,
  },
});
