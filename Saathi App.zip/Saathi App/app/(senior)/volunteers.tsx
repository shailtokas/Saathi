import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  ActivityIndicator,
  TouchableOpacity,
} from 'react-native';
import { useRouter } from 'expo-router';
import { Colors } from '@/constants/Colors';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { VolunteerCard } from '@/components/VolunteerCard';
import { supabase } from '@/lib/supabase';
import { ChevronLeft } from 'lucide-react-native';

interface VolunteerData {
  id: string;
  user_id: string;
  is_verified: boolean;
  help_description: string | null;
  available_categories: string[];
  profiles: {
    full_name: string;
    area: string;
    phone: string;
    whatsapp_number: string | null;
  };
}

export default function VolunteersScreen() {
  const { t } = useLanguage();
  const router = useRouter();
  const { profile } = useAuth();
  const [volunteers, setVolunteers] = useState<VolunteerData[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadVolunteers();
  }, [profile?.area]);

  const loadVolunteers = async () => {
    if (!profile) return;

    try {
      const { data, error } = await supabase
        .from('volunteers')
        .select(
          `
          id,
          user_id,
          is_verified,
          help_description,
          available_categories,
          profiles!inner (
            full_name,
            area,
            phone,
            whatsapp_number
          )
        `
        )
        .eq('is_active', true)
        .eq('profiles.area', profile.area);

      if (error) throw error;

      setVolunteers(data || []);
    } catch (error) {
      console.error('Error loading volunteers:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => router.back()}>
          <ChevronLeft size={28} color={Colors.white} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>{t.nearbyVolunteers}</Text>
      </View>

      {loading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={Colors.primary} />
        </View>
      ) : (
        <ScrollView
          style={styles.scrollView}
          contentContainerStyle={styles.content}>
          {volunteers.length === 0 ? (
            <View style={styles.emptyContainer}>
              <Text style={styles.emptyText}>{t.noVolunteers}</Text>
            </View>
          ) : (
            volunteers.map((volunteer) => (
              <VolunteerCard
                key={volunteer.id}
                name={volunteer.profiles.full_name}
                area={volunteer.profiles.area}
                phone={volunteer.profiles.phone}
                whatsapp={volunteer.profiles.whatsapp_number || undefined}
                helpDescription={volunteer.help_description || undefined}
                isVerified={volunteer.is_verified}
                categories={volunteer.available_categories}
              />
            ))
          )}
        </ScrollView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  header: {
    backgroundColor: Colors.primary,
    paddingTop: 50,
    paddingBottom: 20,
    paddingHorizontal: 16,
    flexDirection: 'row',
    alignItems: 'center',
  },
  backButton: {
    marginRight: 16,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: '700',
    color: Colors.white,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  scrollView: {
    flex: 1,
  },
  content: {
    padding: 24,
  },
  emptyContainer: {
    alignItems: 'center',
    paddingVertical: 40,
  },
  emptyText: {
    fontSize: 18,
    color: Colors.textSecondary,
    textAlign: 'center',
  },
});
