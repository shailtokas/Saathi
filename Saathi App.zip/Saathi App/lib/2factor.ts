const TWOFACTOR_API_KEY = process.env.EXPO_PUBLIC_2FACTOR_API_KEY!;
const TWOFACTOR_API_URL = 'https://2factor.in/API/V1';

// SMS-only OTP delivery - using 2Factor AUTOGEN SMS endpoint
// ABSOLUTELY NO VOICE/CALL DELIVERY - SMS ONLY
export async function send2FactorOTP(mobile: string): Promise<{ success: boolean; sessionId?: string; error?: string }> {
  try {
    console.log('==========================================================');
    console.log('2FACTOR OTP SEND - SMS ONLY (NO VOICE/CALL)');
    console.log('==========================================================');
    console.log('Mobile:', mobile);
    console.log('API Key Present:', TWOFACTOR_API_KEY ? 'YES' : 'NO');

    // HARDCODED SMS DELIVERY - NO VARIABLES - NO VOICE/CALL POSSIBLE
    const deliveryMethod = 'SMS'; // Locked to SMS
    const baseUrl = 'https://2factor.in/API/V1';

    // Construct URL with explicit SMS path
    const url = `${baseUrl}/${TWOFACTOR_API_KEY}/${deliveryMethod}/${mobile}/AUTOGEN`;

    console.log('Constructed URL:', url);
    console.log('URL Check - Contains /SMS/:', url.includes('/SMS/'));
    console.log('URL Check - Contains /VOICE/:', url.includes('/VOICE/'));
    console.log('URL Check - Contains voice (lowercase):', url.toLowerCase().includes('voice'));
    console.log('URL Check - Contains /CALL/:', url.includes('/CALL/'));

    // Triple-check: Ensure URL contains SMS and not VOICE
    if (!url.includes('/SMS/')) {
      const error = 'CRITICAL ERROR: SMS path not found in URL. Aborting.';
      console.error(error);
      throw new Error(error);
    }
    if (url.includes('/VOICE/') || url.toLowerCase().includes('voice') || url.includes('/CALL/')) {
      const error = 'CRITICAL ERROR: Voice/Call path detected. SMS only allowed.';
      console.error(error);
      throw new Error(error);
    }

    console.log('✓ URL VALIDATION PASSED - SMS ONLY CONFIRMED');
    console.log('Calling 2Factor API now...');

    const response = await fetch(url, {
      method: 'GET',
    });

    console.log('=== 2Factor API Response ===');
    console.log('Status:', response.status);
    console.log('Status Text:', response.statusText);

    const data = await response.json();
    console.log('Response Data:', data);

    if (data.Status === 'Success') {
      return {
        success: true,
        sessionId: data.Details,
      };
    } else {
      return {
        success: false,
        error: data.Details || 'Failed to send OTP',
      };
    }
  } catch (error: any) {
    console.error('Send OTP Error:', error);
    return {
      success: false,
      error: error.message || 'Network error. Please check your connection.',
    };
  }
}

// Verify SMS OTP only - NO VOICE/CALL VERIFICATION
export async function verify2FactorOTP(sessionId: string, otp: string): Promise<{ success: boolean; error?: string }> {
  try {
    console.log('==========================================================');
    console.log('2FACTOR OTP VERIFY - SMS ONLY (NO VOICE/CALL)');
    console.log('==========================================================');
    console.log('Session ID:', sessionId);
    console.log('OTP Length:', otp.length);

    // HARDCODED SMS VERIFICATION - NO VARIABLES - NO VOICE/CALL POSSIBLE
    const deliveryMethod = 'SMS'; // Locked to SMS
    const baseUrl = 'https://2factor.in/API/V1';

    // Construct verification URL with explicit SMS path
    const url = `${baseUrl}/${TWOFACTOR_API_KEY}/${deliveryMethod}/VERIFY/${sessionId}/${otp}`;

    console.log('Constructed Verify URL:', url);
    console.log('URL Check - Contains /SMS/:', url.includes('/SMS/'));
    console.log('URL Check - Contains /VOICE/:', url.includes('/VOICE/'));
    console.log('URL Check - Contains voice (lowercase):', url.toLowerCase().includes('voice'));
    console.log('URL Check - Contains /CALL/:', url.includes('/CALL/'));

    // Triple-check: Ensure URL contains SMS and not VOICE
    if (!url.includes('/SMS/')) {
      const error = 'CRITICAL ERROR: SMS path not found in verify URL. Aborting.';
      console.error(error);
      throw new Error(error);
    }
    if (url.includes('/VOICE/') || url.toLowerCase().includes('voice') || url.includes('/CALL/')) {
      const error = 'CRITICAL ERROR: Voice/Call path detected in verify. SMS only allowed.';
      console.error(error);
      throw new Error(error);
    }

    console.log('✓ URL VALIDATION PASSED - SMS ONLY CONFIRMED');
    console.log('Calling 2Factor Verify API now...');

    const response = await fetch(url, {
      method: 'GET',
    });

    console.log('=== 2Factor Verify Response ===');
    console.log('Status:', response.status);
    console.log('Status Text:', response.statusText);

    const data = await response.json();
    console.log('Response Data:', data);

    if (data.Status === 'Success') {
      return {
        success: true,
      };
    } else {
      return {
        success: false,
        error: data.Details || 'Invalid OTP',
      };
    }
  } catch (error: any) {
    console.error('Verify OTP Error:', error);
    return {
      success: false,
      error: error.message || 'Network error. Please check your connection.',
    };
  }
}
