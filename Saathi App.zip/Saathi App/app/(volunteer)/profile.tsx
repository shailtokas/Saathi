import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Alert,
  ActivityIndicator,
} from 'react-native';
import { useRouter } from 'expo-router';
import { Colors } from '@/constants/Colors';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/Button';
import { Card } from '@/components/Card';
import {
  User,
  MapPin,
  Phone,
  Languages,
  ShieldCheck,
} from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

interface VolunteerProfile {
  is_verified: boolean;
  help_description: string | null;
  available_categories: string[];
  is_active: boolean;
  total_helps: number;
}

export default function VolunteerProfileScreen() {
  const { t, language, setLanguage } = useLanguage();
  const { profile, signOut } = useAuth();
  const router = useRouter();
  const [volunteerData, setVolunteerData] = useState<VolunteerProfile | null>(
    null
  );
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (profile?.id) {
      loadVolunteerData();
    } else {
      setLoading(false);
    }
  }, [profile?.id]);

  const loadVolunteerData = async () => {
    if (!profile) return;

    try {
      const { data, error } = await supabase
        .from('volunteers')
        .select('*')
        .eq('user_id', profile.id)
        .maybeSingle();

      if (error) throw error;

      setVolunteerData(data);
    } catch (error) {
      console.error('Error loading volunteer data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = () => {
    Alert.alert(
      t.logout,
      'Are you sure you want to logout?',
      [
        { text: t.cancel, style: 'cancel' },
        {
          text: t.logout,
          style: 'destructive',
          onPress: async () => {
            await signOut();
            router.replace('/');
          },
        },
      ],
      { cancelable: true }
    );
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={Colors.primary} />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>{t.profile}</Text>
      </View>

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.content}>
        <Card style={styles.profileCard}>
          <View style={styles.avatarContainer}>
            <View style={styles.avatar}>
              <User size={48} color={Colors.primary} />
            </View>
            {volunteerData?.is_verified && (
              <View style={styles.verifiedBadge}>
                <ShieldCheck size={24} color={Colors.success} />
              </View>
            )}
          </View>
          <Text style={styles.name}>{profile?.full_name}</Text>
          <Text style={styles.role}>{t.wantToHelp}</Text>
          {volunteerData?.is_verified && (
            <View style={styles.verifiedLabel}>
              <Text style={styles.verifiedText}>{t.verified}</Text>
            </View>
          )}
        </Card>

        <Card style={styles.statsCard}>
          <Text style={styles.statsTitle}>Volunteer Stats</Text>
          <View style={styles.statsRow}>
            <View style={styles.statItem}>
              <Text style={styles.statValue}>
                {volunteerData?.total_helps || 0}
              </Text>
              <Text style={styles.statLabel}>Helps Completed</Text>
            </View>
            <View style={styles.statItem}>
              <Text
                style={[
                  styles.statValue,
                  {
                    color: volunteerData?.is_active
                      ? Colors.success
                      : Colors.textSecondary,
                  },
                ]}>
                {volunteerData?.is_active ? 'Active' : 'Inactive'}
              </Text>
              <Text style={styles.statLabel}>Status</Text>
            </View>
          </View>
        </Card>

        <Card style={styles.infoCard}>
          <View style={styles.infoRow}>
            <Phone size={20} color={Colors.textSecondary} />
            <Text style={styles.infoLabel}>{t.phoneNumber}:</Text>
            <Text style={styles.infoValue}>{profile?.phone}</Text>
          </View>
          {profile?.whatsapp_number && (
            <View style={styles.infoRow}>
              <Phone size={20} color={Colors.textSecondary} />
              <Text style={styles.infoLabel}>{t.whatsappNumber}:</Text>
              <Text style={styles.infoValue}>{profile.whatsapp_number}</Text>
            </View>
          )}
          <View style={styles.infoRow}>
            <MapPin size={20} color={Colors.textSecondary} />
            <Text style={styles.infoLabel}>{t.area}:</Text>
            <Text style={styles.infoValue}>{profile?.area}</Text>
          </View>
          <View style={styles.infoRow}>
            <MapPin size={20} color={Colors.textSecondary} />
            <Text style={styles.infoLabel}>{t.pinCode}:</Text>
            <Text style={styles.infoValue}>{profile?.pin_code}</Text>
          </View>
        </Card>

        {volunteerData?.help_description && (
          <Card style={styles.descriptionCard}>
            <Text style={styles.descriptionTitle}>{t.helpDescription}</Text>
            <Text style={styles.descriptionText}>
              {volunteerData.help_description}
            </Text>
          </Card>
        )}

        {volunteerData?.available_categories &&
          volunteerData.available_categories.length > 0 && (
            <Card style={styles.categoriesCard}>
              <Text style={styles.categoriesTitle}>{t.availableFor}</Text>
              <View style={styles.categories}>
                {volunteerData.available_categories.map((cat, index) => (
                  <View key={index} style={styles.categoryTag}>
                    <Text style={styles.categoryText}>
                      {
                        t.helpCategories[
                          cat as keyof typeof t.helpCategories
                        ]
                      }
                    </Text>
                  </View>
                ))}
              </View>
            </Card>
          )}

        <Card style={styles.languageCard}>
          <View style={styles.languageHeader}>
            <Languages size={24} color={Colors.textDark} />
            <Text style={styles.languageTitle}>Language / भाषा</Text>
          </View>
          <View style={styles.languageButtons}>
            <Button
              title="English"
              onPress={() => setLanguage('en')}
              variant={language === 'en' ? 'primary' : 'outline'}
              size="medium"
              style={styles.languageButton}
            />
            <Button
              title="हिंदी"
              onPress={() => setLanguage('hi')}
              variant={language === 'hi' ? 'primary' : 'outline'}
              size="medium"
              style={styles.languageButton}
            />
          </View>
        </Card>

        <Button
          title={t.safetyGuidelines}
          onPress={() => router.push('/safety')}
          variant="secondary"
          size="medium"
        />

        <View style={styles.spacer} />

        <Button
          title={t.logout}
          onPress={handleLogout}
          variant="outline"
          size="medium"
        />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: Colors.background,
  },
  header: {
    backgroundColor: Colors.primary,
    paddingTop: 50,
    paddingBottom: 20,
    paddingHorizontal: 24,
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: '700',
    color: Colors.white,
  },
  scrollView: {
    flex: 1,
  },
  content: {
    padding: 24,
  },
  profileCard: {
    alignItems: 'center',
    marginBottom: 20,
  },
  avatarContainer: {
    marginBottom: 16,
    position: 'relative',
  },
  avatar: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: Colors.lightGray,
    justifyContent: 'center',
    alignItems: 'center',
  },
  verifiedBadge: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    backgroundColor: Colors.white,
    borderRadius: 12,
    padding: 4,
  },
  name: {
    fontSize: 28,
    fontWeight: '700',
    color: Colors.textDark,
    marginBottom: 4,
  },
  role: {
    fontSize: 18,
    color: Colors.textSecondary,
    marginBottom: 8,
  },
  verifiedLabel: {
    backgroundColor: Colors.success,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
  },
  verifiedText: {
    color: Colors.white,
    fontSize: 14,
    fontWeight: '600',
  },
  statsCard: {
    marginBottom: 20,
  },
  statsTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: Colors.textDark,
    marginBottom: 16,
  },
  statsRow: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  statItem: {
    alignItems: 'center',
  },
  statValue: {
    fontSize: 32,
    fontWeight: '800',
    color: Colors.primary,
  },
  statLabel: {
    fontSize: 14,
    color: Colors.textSecondary,
    marginTop: 4,
  },
  infoCard: {
    marginBottom: 20,
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  infoLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: Colors.textSecondary,
    marginLeft: 12,
    marginRight: 8,
  },
  infoValue: {
    fontSize: 16,
    color: Colors.textDark,
  },
  descriptionCard: {
    marginBottom: 20,
  },
  descriptionTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: Colors.textDark,
    marginBottom: 8,
  },
  descriptionText: {
    fontSize: 16,
    color: Colors.textSecondary,
    lineHeight: 24,
  },
  categoriesCard: {
    marginBottom: 20,
  },
  categoriesTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: Colors.textDark,
    marginBottom: 12,
  },
  categories: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  categoryTag: {
    backgroundColor: Colors.lightGray,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
  },
  categoryText: {
    fontSize: 14,
    color: Colors.primary,
    fontWeight: '600',
  },
  languageCard: {
    marginBottom: 20,
  },
  languageHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  languageTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: Colors.textDark,
    marginLeft: 12,
  },
  languageButtons: {
    flexDirection: 'row',
    gap: 12,
  },
  languageButton: {
    flex: 1,
  },
  spacer: {
    height: 20,
  },
});
