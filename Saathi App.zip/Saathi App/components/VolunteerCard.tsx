import React from 'react';
import { View, Text, StyleSheet, Linking } from 'react-native';
import { Phone, MessageCircle, ShieldCheck } from 'lucide-react-native';
import { Card } from './Card';
import { Button } from './Button';
import { Colors } from '@/constants/Colors';
import { useLanguage } from '@/contexts/LanguageContext';

interface VolunteerCardProps {
  name: string;
  area: string;
  phone: string;
  whatsapp?: string;
  helpDescription?: string;
  isVerified: boolean;
  categories: string[];
}

export function VolunteerCard({
  name,
  area,
  phone,
  whatsapp,
  helpDescription,
  isVerified,
  categories,
}: VolunteerCardProps) {
  const { t } = useLanguage();

  const handleCall = () => {
    Linking.openURL(`tel:${phone}`);
  };

  const handleWhatsApp = () => {
    const message = encodeURIComponent(t.contactBeforeHelp);
    Linking.openURL(`https://wa.me/${whatsapp}?text=${message}`);
  };

  return (
    <Card style={styles.card}>
      <View style={styles.header}>
        <View style={styles.nameContainer}>
          <Text style={styles.name}>{name}</Text>
          {isVerified && (
            <View style={styles.badge}>
              <ShieldCheck size={18} color={Colors.success} />
              <Text style={styles.badgeText}>{t.verified}</Text>
            </View>
          )}
        </View>
        <Text style={styles.area}>{area}</Text>
      </View>

      {helpDescription && (
        <Text style={styles.description}>{helpDescription}</Text>
      )}

      {categories.length > 0 && (
        <View style={styles.categories}>
          {categories.map((cat, index) => (
            <View key={index} style={styles.categoryTag}>
              <Text style={styles.categoryText}>
                {t.helpCategories[cat as keyof typeof t.helpCategories] || cat}
              </Text>
            </View>
          ))}
        </View>
      )}

      <View style={styles.actions}>
        <Button
          title={t.call}
          onPress={handleCall}
          variant="primary"
          size="medium"
          style={styles.actionButton}
        />
        {whatsapp && (
          <Button
            title={t.whatsapp}
            onPress={handleWhatsApp}
            variant="secondary"
            size="medium"
            style={styles.actionButton}
          />
        )}
      </View>
    </Card>
  );
}

const styles = StyleSheet.create({
  card: {
    marginBottom: 16,
  },
  header: {
    marginBottom: 12,
  },
  nameContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4,
    flexWrap: 'wrap',
  },
  name: {
    fontSize: 22,
    fontWeight: '700',
    color: Colors.textDark,
    marginRight: 8,
  },
  badge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.lightGray,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
  },
  badgeText: {
    fontSize: 14,
    color: Colors.success,
    marginLeft: 4,
    fontWeight: '600',
  },
  area: {
    fontSize: 18,
    color: Colors.textSecondary,
  },
  description: {
    fontSize: 16,
    color: Colors.textDark,
    marginBottom: 12,
    lineHeight: 24,
  },
  categories: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginBottom: 16,
  },
  categoryTag: {
    backgroundColor: Colors.background,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
    marginRight: 8,
    marginBottom: 8,
  },
  categoryText: {
    fontSize: 14,
    color: Colors.primary,
    fontWeight: '600',
  },
  actions: {
    flexDirection: 'row',
    gap: 12,
  },
  actionButton: {
    flex: 1,
  },
});
