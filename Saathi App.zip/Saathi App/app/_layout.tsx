import { useEffect } from 'react';
import { Stack, useRouter, useSegments } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { View, Platform } from 'react-native';
import * as SplashScreen from 'expo-splash-screen';
import { useFrameworkReady } from '@/hooks/useFrameworkReady';
import { AuthProvider, useAuth } from '@/contexts/AuthContext';
import { LanguageProvider } from '@/contexts/LanguageContext';
import { Colors } from '@/constants/Colors';

if (Platform.OS === 'web') {
  require('../global.css');
}

SplashScreen.preventAutoHideAsync();

function RootNavigator() {
  const { phoneSession, isReady, logoutKey } = useAuth();
  const router = useRouter();
  const segments = useSegments();

  useEffect(() => {
    if (!isReady) return;

    SplashScreen.hideAsync();

    const inAuthGroup = segments[0] === '(senior)' || segments[0] === '(volunteer)';

    if (!phoneSession && inAuthGroup) {
      router.replace('/');
    }
  }, [phoneSession, isReady, logoutKey, segments, router]);

  return (
    <Stack
      screenOptions={{
        headerShown: false,
        contentStyle: { backgroundColor: Colors.background },
        animation: 'none',
      }}>
      <Stack.Screen name="+not-found" />
    </Stack>
  );
}

export default function RootLayout() {
  useFrameworkReady();

  return (
    <View style={{ flex: 1, backgroundColor: Colors.background }}>
      <AuthProvider>
        <LanguageProvider>
          <RootNavigator />
          <StatusBar style="auto" />
        </LanguageProvider>
      </AuthProvider>
    </View>
  );
}
