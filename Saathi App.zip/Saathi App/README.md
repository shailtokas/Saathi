# RACE Saathi - Helping Hands for Seniors

A mobile-first web app connecting senior citizens with nearby volunteers for simple help like medicine, doctor visits, groceries, or someone to talk to.

## Features

### For Seniors
- Large, easy-to-tap buttons with readable fonts
- Simple OTP-based phone login
- Create help requests with categories (Medicine, Doctor, Grocery, Talk)
- View nearby verified volunteers
- Direct call and WhatsApp communication
- Emergency SOS contacts page
- Track request status (Open, In Progress, Completed)
- Bilingual support (English/Hindi)

### For Volunteers
- Browse open help requests in your area
- View requests filtered by location
- Direct contact seniors via phone or WhatsApp
- Profile with verified badge status
- Track completed helps
- Manage availability status

## Tech Stack

- **Framework**: React Native with Expo
- **Routing**: Expo Router with tabs
- **Database**: Supabase (PostgreSQL)
- **Authentication**: Supabase Auth with OTP
- **Styling**: React Native StyleSheet (senior-friendly design)
- **Icons**: Lucide React Native

## Database Schema

### Tables
1. **profiles** - User profiles (both seniors and volunteers)
2. **volunteers** - Extended volunteer information
3. **help_requests** - Help requests from seniors
4. **sos_contacts** - Emergency contacts for users

All tables have Row Level Security (RLS) enabled with proper policies for data protection.

## Design Principles

- **Senior-Friendly**: Large touch targets (min 70px height), readable fonts (18-28px), high contrast colors
- **Simple Navigation**: Maximum 2-3 taps to reach any feature
- **Trust & Safety**: Verified volunteer badges, safety guidelines, emergency contacts
- **Local Focus**: Area-based filtering ensures relevant connections
- **Direct Communication**: Phone and WhatsApp integration (no complex in-app chat)

## Color Palette

- Primary Green: #2E7D32
- Background: #F9FAF7
- Secondary Blue: #4A90E2
- Success Green: #66BB6A
- SOS Red: #D32F2F
- Warning Amber: #F9A825

## Getting Started

1. The Supabase database is already configured with environment variables in `.env`
2. Database schema has been created with proper security policies
3. Run the development server to start using the app
4. For OTP login to work, configure Supabase Auth settings in your Supabase dashboard

## User Flow

### For Seniors:
1. Landing page → "Need Help" button
2. OTP login with phone number
3. Complete profile (name, area, pin code)
4. Dashboard with options to:
   - Create help request
   - View nearby volunteers
   - Access SOS emergency contacts
   - View your requests

### For Volunteers:
1. Landing page → "Want to Help" button
2. OTP login with phone number
3. Complete profile (name, area, categories of help)
4. Dashboard showing:
   - Open help requests in your area
   - Direct contact options (Call/WhatsApp)
   - Your volunteer stats

## Safety Features

- Safety guidelines page with best practices
- Emergency contact numbers (Police, Ambulance, Helplines)
- Reminder to make initial contact via phone
- Area-based filtering for local connections only
- Verified volunteer badges

## Bilingual Support

The app supports both English and Hindi languages with full translation of:
- UI labels and buttons
- Help categories
- Status indicators
- Safety guidelines

Users can switch language anytime from their profile page.

## Important Notes

- OTP authentication requires Supabase Auth to be configured with a phone provider
- For testing, you may need to add test phone numbers in Supabase Auth settings
- The app is optimized for mobile web but works on all devices
- All communication happens via native phone/WhatsApp apps for simplicity
