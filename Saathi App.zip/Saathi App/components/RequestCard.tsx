import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Card } from './Card';
import { Colors } from '@/constants/Colors';
import { useLanguage } from '@/contexts/LanguageContext';

interface RequestCardProps {
  title: string;
  description: string;
  category: string;
  urgency: string;
  status: string;
  area: string;
  createdAt: string;
}

export function RequestCard({
  title,
  description,
  category,
  urgency,
  status,
  area,
  createdAt,
}: RequestCardProps) {
  const { t } = useLanguage();

  const getStatusColor = () => {
    switch (status) {
      case 'open':
        return Colors.warning;
      case 'in_progress':
        return Colors.secondary;
      case 'completed':
        return Colors.success;
      default:
        return Colors.textSecondary;
    }
  };

  const getUrgencyColor = () => {
    switch (urgency) {
      case 'high':
        return Colors.sos;
      case 'medium':
        return Colors.warning;
      case 'low':
        return Colors.success;
      default:
        return Colors.textSecondary;
    }
  };

  return (
    <Card style={styles.card}>
      <View style={styles.header}>
        <Text style={styles.title}>{title}</Text>
        <View style={styles.badges}>
          <View
            style={[styles.badge, { backgroundColor: getStatusColor() }]}>
            <Text style={styles.badgeText}>
              {t.status[status as keyof typeof t.status]}
            </Text>
          </View>
          <View
            style={[
              styles.badge,
              { backgroundColor: getUrgencyColor() },
            ]}>
            <Text style={styles.badgeText}>
              {t.urgency[urgency as keyof typeof t.urgency]}
            </Text>
          </View>
        </View>
      </View>

      <Text style={styles.description}>{description}</Text>

      <View style={styles.meta}>
        <View style={styles.metaItem}>
          <Text style={styles.metaLabel}>{t.category}:</Text>
          <Text style={styles.metaValue}>
            {t.helpCategories[category as keyof typeof t.helpCategories] ||
              category}
          </Text>
        </View>
        <View style={styles.metaItem}>
          <Text style={styles.metaLabel}>{t.area}:</Text>
          <Text style={styles.metaValue}>{area}</Text>
        </View>
        <View style={styles.metaItem}>
          <Text style={styles.metaLabel}>
            {new Date(createdAt).toLocaleDateString()}
          </Text>
        </View>
      </View>
    </Card>
  );
}

const styles = StyleSheet.create({
  card: {
    marginBottom: 16,
  },
  header: {
    marginBottom: 12,
  },
  title: {
    fontSize: 20,
    fontWeight: '700',
    color: Colors.textDark,
    marginBottom: 8,
  },
  badges: {
    flexDirection: 'row',
    gap: 8,
    flexWrap: 'wrap',
  },
  badge: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 6,
  },
  badgeText: {
    color: Colors.white,
    fontSize: 14,
    fontWeight: '600',
  },
  description: {
    fontSize: 16,
    color: Colors.textDark,
    marginBottom: 12,
    lineHeight: 24,
  },
  meta: {
    borderTopWidth: 1,
    borderTopColor: Colors.border,
    paddingTop: 12,
  },
  metaItem: {
    flexDirection: 'row',
    marginBottom: 4,
  },
  metaLabel: {
    fontSize: 14,
    color: Colors.textSecondary,
    marginRight: 8,
    fontWeight: '600',
  },
  metaValue: {
    fontSize: 14,
    color: Colors.textDark,
  },
});
