import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Linking,
  Alert,
  ActivityIndicator,
} from 'react-native';
import { Colors } from '@/constants/Colors';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/Button';
import { Card } from '@/components/Card';
import { supabase } from '@/lib/supabase';
import { ShieldAlert } from 'lucide-react-native';

interface SOSContact {
  id: string;
  contact_name: string;
  contact_phone: string;
  contact_whatsapp: string | null;
  is_primary: boolean;
}

export default function SOSScreen() {
  const { t } = useLanguage();
  const { profile } = useAuth();
  const [contacts, setContacts] = useState<SOSContact[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (profile?.id) {
      loadSOSContacts();
    } else {
      setLoading(false);
    }
  }, [profile?.id]);

  const loadSOSContacts = async () => {
    if (!profile) return;

    try {
      const { data, error } = await supabase
        .from('sos_contacts')
        .select('*')
        .eq('user_id', profile.id)
        .order('is_primary', { ascending: false });

      if (error) throw error;

      setContacts(data || []);
    } catch (error) {
      console.error('Error loading SOS contacts:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleEmergencyCall = (phone: string, name: string) => {
    Alert.alert(
      t.emergency,
      `Call ${name}?`,
      [
        { text: t.cancel, style: 'cancel' },
        {
          text: t.call,
          onPress: () => Linking.openURL(`tel:${phone}`),
        },
      ],
      { cancelable: true }
    );
  };

  const handleWhatsAppSOS = (phone: string) => {
    const message = encodeURIComponent(t.sosMessage);
    Linking.openURL(`https://wa.me/${phone}?text=${message}`);
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <ShieldAlert size={48} color={Colors.white} />
        <Text style={styles.headerTitle}>{t.sos}</Text>
        <Text style={styles.headerSubtitle}>{t.emergency}</Text>
      </View>

      {loading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={Colors.sos} />
        </View>
      ) : (
        <ScrollView
          style={styles.scrollView}
          contentContainerStyle={styles.content}>
          {contacts.length === 0 ? (
            <Card>
              <Text style={styles.emptyText}>
                No emergency contacts added yet. Please add contacts in your
                profile.
              </Text>
            </Card>
          ) : (
            contacts.map((contact) => (
              <Card key={contact.id} style={styles.contactCard}>
                <View style={styles.contactHeader}>
                  <Text style={styles.contactName}>{contact.contact_name}</Text>
                  {contact.is_primary && (
                    <View style={styles.primaryBadge}>
                      <Text style={styles.primaryText}>Primary</Text>
                    </View>
                  )}
                </View>
                <Text style={styles.contactPhone}>{contact.contact_phone}</Text>
                <View style={styles.contactActions}>
                  <Button
                    title={t.call}
                    onPress={() =>
                      handleEmergencyCall(
                        contact.contact_phone,
                        contact.contact_name
                      )
                    }
                    variant="sos"
                    size="medium"
                    style={styles.actionButton}
                  />
                  {contact.contact_whatsapp && (
                    <Button
                      title={t.whatsapp}
                      onPress={() =>
                        handleWhatsAppSOS(contact.contact_whatsapp!)
                      }
                      variant="secondary"
                      size="medium"
                      style={styles.actionButton}
                    />
                  )}
                </View>
              </Card>
            ))
          )}

          <Card style={styles.infoCard}>
            <Text style={styles.infoText}>
              Press the call button above to immediately contact your emergency
              contact. Make sure to add emergency contacts in your profile.
            </Text>
          </Card>
        </ScrollView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  header: {
    backgroundColor: Colors.sos,
    paddingTop: 50,
    paddingBottom: 32,
    paddingHorizontal: 24,
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 32,
    fontWeight: '800',
    color: Colors.white,
    marginTop: 12,
  },
  headerSubtitle: {
    fontSize: 18,
    color: Colors.white,
    marginTop: 4,
    opacity: 0.9,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  scrollView: {
    flex: 1,
  },
  content: {
    padding: 24,
  },
  emptyText: {
    fontSize: 16,
    color: Colors.textSecondary,
    textAlign: 'center',
    lineHeight: 24,
  },
  contactCard: {
    marginBottom: 16,
  },
  contactHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  contactName: {
    fontSize: 22,
    fontWeight: '700',
    color: Colors.textDark,
  },
  primaryBadge: {
    backgroundColor: Colors.warning,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 6,
  },
  primaryText: {
    fontSize: 12,
    fontWeight: '700',
    color: Colors.white,
  },
  contactPhone: {
    fontSize: 18,
    color: Colors.textSecondary,
    marginBottom: 16,
  },
  contactActions: {
    flexDirection: 'row',
    gap: 12,
  },
  actionButton: {
    flex: 1,
  },
  infoCard: {
    backgroundColor: Colors.lightGray,
    marginTop: 8,
  },
  infoText: {
    fontSize: 16,
    color: Colors.textSecondary,
    lineHeight: 24,
    textAlign: 'center',
  },
});
