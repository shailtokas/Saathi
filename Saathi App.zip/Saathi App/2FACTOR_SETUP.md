# 2Factor SMS OTP Authentication Setup

This app uses 2Factor.in for **SMS-only** OTP phone authentication with a simple .env-based configuration.

**Note:** This implementation uses SMS delivery only. Voice/call OTP is not supported.

## Setup Instructions

### 1. Get 2Factor API Key

1. Sign up at [2Factor.in](https://2factor.in/)
2. Go to your Dashboard
3. Copy your API Key

### 2. Configure Environment Variable

Add your 2Factor API key to the `.env` file:

```bash
EXPO_PUBLIC_2FACTOR_API_KEY=your_actual_api_key_here
```

That's it! The app reads the API key directly from the `.env` file.

### 3. Test the Flow

1. Start the dev server: `npm run dev`
2. Click "Need Help" or "Want to Help"
3. Enter a 10-digit Indian mobile number (without +91)
4. Click "Send OTP"
5. Check your SMS for the OTP
6. Enter the 6-digit OTP
7. Click "Verify"

## How It Works

The app calls the 2Factor.in API directly from the client using the API key from `.env`:

### Send SMS OTP
- User enters phone number
- App calls: `GET https://2factor.in/API/V1/{API_KEY}/SMS/91{mobile}/AUTOGEN`
- 2Factor sends OTP via **SMS only** (not voice) and returns a session ID
- Session ID is stored temporarily in the app state

### Verify OTP
- User enters the OTP received via SMS
- App calls: `GET https://2factor.in/API/V1/{API_KEY}/SMS/VERIFY/{session_id}/{otp}`
- If verified, app checks if user exists in the database
- Existing users are routed to their dashboard
- New users are sent to profile setup

## Implementation Details

All 2Factor integration logic is in `lib/2factor.ts`:
- `send2FactorOTP(mobile)` - Sends OTP and returns session ID
- `verify2FactorOTP(sessionId, otp)` - Verifies the OTP code

## Security Notes

- API key is stored in environment variables (not in code)
- OTP is generated and validated by 2Factor servers
- Session IDs are temporary and expire
- Direct API calls mean no Edge Function dependency

## Cost

2Factor charges per SMS. Check their [pricing page](https://2factor.in/pricing) for current rates.

## Troubleshooting

### "2Factor API key not configured"
- Make sure you've added `EXPO_PUBLIC_2FACTOR_API_KEY` to `.env`
- Restart the dev server after updating `.env`

### "Failed to send OTP"
- Check your 2Factor account balance
- Verify the API key is correct in `.env`
- Ensure the phone number is valid (10 digits)

### "Invalid OTP"
- OTPs expire after a few minutes
- Request a new OTP if expired
- Ensure you're entering the correct 6-digit code

### Network Errors
- Check your internet connection
- Verify 2Factor.in service status
- Check browser console for detailed error messages
