# Deployment Checklist - Profile Save Flow Fix

## Pre-Deployment Tasks

### 1. Database Migration ⚠️ CRITICAL
- [ ] Open Supabase Dashboard
- [ ] Navigate to SQL Editor
- [ ] Copy contents of `supabase/migrations/20260402000000_fix_phone_auth_rls.sql`
- [ ] Paste and execute in SQL Editor
- [ ] Verify: Check profiles table - should have no FK to auth.users
- [ ] Verify: Test insert as anon role (should succeed)

### 2. Code Review
- [ ] Review `lib/session.ts` - Session management utilities
- [ ] Review `contexts/AuthContext.tsx` - Phone session support
- [ ] Review `app/login.tsx` - Session save on login
- [ ] Review `app/setup-profile.tsx` - Session save on signup
- [ ] Review `app/index.tsx` - Auto-navigation enabled

### 3. TypeScript Check
```bash
npm run typecheck
```
- [ ] Should pass with no errors

### 4. Build Test
```bash
npm run build:web
```
- [ ] Should complete successfully

## Testing Phase

### Test 1: Fresh User Signup
- [ ] Open app in incognito/private window
- [ ] Click "Need Help"
- [ ] Enter phone: `[test-number]`
- [ ] Receive and enter OTP
- [ ] Fill profile form completely
- [ ] Click "Save Profile"
- [ ] **Expected:** Success, redirect to home
- [ ] **Expected:** Profile displays in header
- [ ] **Check DevTools:** localStorage has `race_saathi_session`

### Test 2: Page Reload
- [ ] After Test 1, press F5 to reload
- [ ] **Expected:** Auto-redirects to home
- [ ] **Expected:** Profile still loaded
- [ ] **Expected:** User still logged in
- [ ] **Check Console:** "Profile loaded from phone session"

### Test 3: Close & Reopen Browser
- [ ] Close browser completely
- [ ] Reopen and navigate to app
- [ ] **Expected:** Auto-login works
- [ ] **Expected:** Redirects to home
- [ ] **Expected:** Profile loaded

### Test 4: Existing User Login
- [ ] Logout (clear localStorage)
- [ ] Enter same phone from Test 1
- [ ] Verify OTP
- [ ] **Expected:** Direct redirect to home (no profile setup)
- [ ] **Expected:** Profile loaded correctly

### Test 5: Session Expiry
- [ ] Login successfully
- [ ] DevTools → Application → localStorage
- [ ] Edit `race_saathi_session` timestamp to 25 hours ago
- [ ] Reload page
- [ ] **Expected:** Redirects to landing page
- [ ] **Expected:** Must login again

### Test 6: Volunteer Flow
- [ ] Repeat Test 1 but click "Want to Help"
- [ ] Fill volunteer-specific fields
- [ ] Save profile
- [ ] **Expected:** Redirects to volunteer home
- [ ] **Expected:** Volunteer profile created
- [ ] Reload page
- [ ] **Expected:** Still logged in as volunteer

### Test 7: Profile Display
- [ ] After login, navigate to Profile tab
- [ ] **Expected:** All profile data displays correctly
- [ ] **Expected:** No errors in console
- [ ] Try updating profile (if feature exists)

### Test 8: Help Request Creation (Senior)
- [ ] Login as senior
- [ ] Click "Create Request"
- [ ] Fill form and submit
- [ ] **Expected:** Success message
- [ ] **Expected:** Request created
- [ ] **Check Console:** No permission errors

## Post-Deployment Verification

### Database Check
- [ ] Open Supabase → Table Editor → profiles
- [ ] Verify test profiles exist
- [ ] Check `id` field - should be UUID
- [ ] Check `phone` field - should be unique
- [ ] Verify volunteers table (for volunteer users)

### Console Logs Check (Success Indicators)
```
✓ Look for these in browser console:

On Signup:
- "✓ Profile saved successfully"
- "✓ Session saved for new user"
- "=== PROFILE SETUP COMPLETE ==="

On Login:
- "✓ Session saved for existing user"
- "Existing user found"

On Reload:
- "Session retrieved"
- "✓ Profile loaded from phone session"
- "Auto-navigating based on profile"
```

### localStorage Check
```javascript
// Run in browser console
const session = JSON.parse(localStorage.getItem('race_saathi_session'));
console.log('Session:', session);

// Should output:
{
  phone: "+91xxxxxxxxxx",
  userId: "uuid-here",
  role: "senior" or "volunteer",
  timestamp: number
}
```

## Rollback Plan (If Issues)

### Quick Rollback
1. Restore old AuthContext:
```bash
cp /tmp/auth_backup.tsx contexts/AuthContext.tsx
```

2. Remove session imports:
- Edit `app/login.tsx` - remove `saveSession` import & call
- Edit `app/setup-profile.tsx` - remove `saveSession` import & call

3. Disable auto-navigation:
- Edit `app/index.tsx` - comment out useEffect

4. Keep migration applied (safe to keep)

### Database Rollback (if needed)
```sql
-- Restore auth FK (only if necessary)
ALTER TABLE profiles
ADD CONSTRAINT profiles_id_fkey
FOREIGN KEY (id) REFERENCES auth.users(id) ON DELETE CASCADE;

-- Recreate old policies (check original migration)
```

## Documentation Files

Reference these for detailed information:

- **FIX_SUMMARY.md** - Quick overview of all changes
- **SESSION_FIX_COMPLETE.md** - Detailed technical documentation
- **QUICK_TEST_GUIDE.md** - Step-by-step testing
- **MIGRATION_INSTRUCTIONS.md** - Database migration guide
- **ARCHITECTURE_DIAGRAM.md** - Visual system architecture
- **DEPLOYMENT_CHECKLIST.md** - This file

## Monitoring & Support

### Key Metrics to Monitor
- [ ] Profile creation success rate
- [ ] Session persistence rate
- [ ] Auto-login success rate
- [ ] Page reload handling
- [ ] Error rates in console

### Common User Issues

**Issue: "Can't save profile"**
- Check: Migration applied?
- Check: Console errors?
- Check: Phone number valid?

**Issue: "Logged out after refresh"**
- Check: localStorage enabled?
- Check: Session object exists?
- Check: Timestamp not expired?

**Issue: "Permission denied"**
- Check: RLS policies applied?
- Check: Using anon role?
- Solution: Re-run migration

## Sign-Off Checklist

### Development
- [ ] All code changes committed
- [ ] TypeScript compilation passes
- [ ] No console errors
- [ ] All features working locally

### Testing
- [ ] All 8 test scenarios passed
- [ ] Session persistence verified
- [ ] Auto-login verified
- [ ] Logout working
- [ ] Session expiry working

### Database
- [ ] Migration applied successfully
- [ ] RLS policies verified
- [ ] Test data visible in tables
- [ ] No foreign key errors

### Documentation
- [ ] All .md files created
- [ ] Code commented where needed
- [ ] README updated (if applicable)
- [ ] Team informed of changes

### Production Ready
- [ ] Build succeeds
- [ ] No TypeScript errors
- [ ] All tests passed
- [ ] Rollback plan documented
- [ ] Monitoring in place

---

**Deployment Date:** __________
**Deployed By:** __________
**Sign-Off:** __________

**Status:** ✅ Ready for Deployment
