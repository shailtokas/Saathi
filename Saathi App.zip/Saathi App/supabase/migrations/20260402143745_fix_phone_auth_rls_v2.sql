/*
  # Fix Phone-Based Authentication RLS - Apply

  ## Critical Fix
  This migration removes the FK constraint from profiles.id to auth.users.id
  which is preventing profile inserts with custom UUIDs.

  ## Changes
  1. Drop foreign key constraint: profiles_id_fkey
  2. Update RLS policies for phone-based authentication
  3. Allow anon role full access (temporary for MVP)
  4. Ensure phone uniqueness

  ## Security Notes
  - Using phone-based OTP authentication (2Factor.in)
  - No Supabase auth.users dependency
  - Custom UUID generation for profile IDs
  - 24-hour session expiry in localStorage
*/

-- CRITICAL: Drop the foreign key constraint to auth.users
ALTER TABLE profiles DROP CONSTRAINT IF EXISTS profiles_id_fkey;

-- Drop all existing RLS policies to start fresh
DROP POLICY IF EXISTS "Users can view all profiles" ON profiles;
DROP POLICY IF EXISTS "Users can update own profile" ON profiles;
DROP POLICY IF EXISTS "Users can insert own profile" ON profiles;
DROP POLICY IF EXISTS "Public can view profiles" ON profiles;
DROP POLICY IF EXISTS "Public can insert profile" ON profiles;
DROP POLICY IF EXISTS "Public can update profiles" ON profiles;

DROP POLICY IF EXISTS "Anyone can view active volunteers" ON volunteers;
DROP POLICY IF EXISTS "Volunteers can update own profile" ON volunteers;
DROP POLICY IF EXISTS "Users can insert volunteer profile" ON volunteers;
DROP POLICY IF EXISTS "Public can view volunteers" ON volunteers;
DROP POLICY IF EXISTS "Public can insert volunteer profile" ON volunteers;
DROP POLICY IF EXISTS "Public can update volunteer profile" ON volunteers;

DROP POLICY IF EXISTS "Seniors can view own requests" ON help_requests;
DROP POLICY IF EXISTS "Volunteers can view requests in their area" ON help_requests;
DROP POLICY IF EXISTS "Seniors can create help requests" ON help_requests;
DROP POLICY IF EXISTS "Seniors can update own requests" ON help_requests;
DROP POLICY IF EXISTS "Volunteers can update assigned requests" ON help_requests;
DROP POLICY IF EXISTS "Public can view help requests" ON help_requests;
DROP POLICY IF EXISTS "Public can create help requests" ON help_requests;
DROP POLICY IF EXISTS "Public can update help requests" ON help_requests;

DROP POLICY IF EXISTS "Users can view own SOS contacts" ON sos_contacts;
DROP POLICY IF EXISTS "Users can create own SOS contacts" ON sos_contacts;
DROP POLICY IF EXISTS "Users can update own SOS contacts" ON sos_contacts;
DROP POLICY IF EXISTS "Users can delete own SOS contacts" ON sos_contacts;
DROP POLICY IF EXISTS "Public can view SOS contacts" ON sos_contacts;
DROP POLICY IF EXISTS "Public can create SOS contacts" ON sos_contacts;
DROP POLICY IF EXISTS "Public can update SOS contacts" ON sos_contacts;
DROP POLICY IF EXISTS "Public can delete SOS contacts" ON sos_contacts;

-- Create new RLS policies for phone-based authentication
-- NOTE: Using broad permissions for MVP. Tighten in production.

-- PROFILES TABLE
CREATE POLICY "Enable read access for all users"
  ON profiles FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Enable insert for all users"
  ON profiles FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Enable update for all users"
  ON profiles FOR UPDATE
  TO anon, authenticated
  USING (true)
  WITH CHECK (true);

-- VOLUNTEERS TABLE
CREATE POLICY "Enable read access for all users"
  ON volunteers FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Enable insert for all users"
  ON volunteers FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Enable update for all users"
  ON volunteers FOR UPDATE
  TO anon, authenticated
  USING (true)
  WITH CHECK (true);

-- HELP_REQUESTS TABLE
CREATE POLICY "Enable read access for all users"
  ON help_requests FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Enable insert for all users"
  ON help_requests FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Enable update for all users"
  ON help_requests FOR UPDATE
  TO anon, authenticated
  USING (true)
  WITH CHECK (true);

-- SOS_CONTACTS TABLE
CREATE POLICY "Enable read access for all users"
  ON sos_contacts FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Enable insert for all users"
  ON sos_contacts FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Enable update for all users"
  ON sos_contacts FOR UPDATE
  TO anon, authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Enable delete for all users"
  ON sos_contacts FOR DELETE
  TO anon, authenticated
  USING (true);

-- Ensure phone uniqueness to prevent duplicate registrations
CREATE UNIQUE INDEX IF NOT EXISTS idx_profiles_phone_unique 
  ON profiles(phone);

-- Add comment for clarity
COMMENT ON TABLE profiles IS 'User profiles table - uses phone-based authentication, no FK to auth.users';
