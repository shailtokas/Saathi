import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  ReactNode,
  useMemo,
  useCallback,
  useRef,
} from 'react';
import { supabase } from '@/lib/supabase';
import { Database } from '@/types/database';
import { getSession, clearSession, UserSession } from '@/lib/session';

type Profile = Database['public']['Tables']['profiles']['Row'];

interface AuthContextType {
  profile: Profile | null;
  phoneSession: UserSession | null;
  loading: boolean;
  isReady: boolean;
  signOut: () => Promise<void>;
  refreshProfile: () => Promise<void>;
  logoutKey: number;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [profile, setProfile] = useState<Profile | null>(null);
  const [phoneSession, setPhoneSession] = useState<UserSession | null>(() => {
    return getSession();
  });
  const [loading, setLoading] = useState(false);
  const [isReady, setIsReady] = useState(false);
  const [logoutKey, setLogoutKey] = useState(0);
  const isInitialized = useRef(false);

  const refreshProfile = useCallback(async () => {
    const currentPhoneSession = getSession();

    if (currentPhoneSession) {
      const { data } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', currentPhoneSession.userId)
        .maybeSingle();

      if (data) {
        setProfile(data);
        setPhoneSession(currentPhoneSession);
      }
    } else {
      setProfile(null);
      setPhoneSession(null);
    }
  }, []);

  useEffect(() => {
    if (isInitialized.current) return;
    isInitialized.current = true;

    const phoneSession = getSession();
    setIsReady(true);

    if (phoneSession) {
      supabase
        .from('profiles')
        .select('*')
        .eq('id', phoneSession.userId)
        .maybeSingle()
        .then(({ data }) => {
          if (data) {
            setProfile(data);
          }
        });
    }
  }, []);

  const signOut = useCallback(async () => {
    setLoading(true);
    clearSession();
    setPhoneSession(null);
    setProfile(null);
    setLogoutKey(prev => prev + 1);
    setLoading(false);
  }, []);

  const value = useMemo<AuthContextType>(
    () => ({
      profile,
      phoneSession,
      loading,
      isReady,
      signOut,
      refreshProfile,
      logoutKey,
    }),
    [profile, phoneSession, loading, isReady, signOut, refreshProfile, logoutKey]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
