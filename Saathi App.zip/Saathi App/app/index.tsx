import React, { useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
} from 'react-native';
import { useRouter, useSegments } from 'expo-router';
import { Colors } from '@/constants/Colors';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/Button';
import { Heart } from 'lucide-react-native';

export default function LandingScreen() {
  const { t, language, setLanguage } = useLanguage();
  const { phoneSession, isReady } = useAuth();
  const router = useRouter();
  const segments = useSegments();
  const hasRedirected = useRef(false);

  useEffect(() => {
    if (!isReady || !phoneSession) {
      hasRedirected.current = false;
      return;
    }

    const inAuthGroup = segments[0] === '(senior)' || segments[0] === '(volunteer)';

    if (!hasRedirected.current && !inAuthGroup) {
      hasRedirected.current = true;

      if (phoneSession.role === 'senior') {
        router.replace('/(senior)/home');
      } else if (phoneSession.role === 'volunteer') {
        router.replace('/(volunteer)/home');
      }
    }
  }, [phoneSession, isReady, segments, router]);

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.content}>
      <View style={styles.header}>
        <View style={styles.iconContainer}>
          <Heart size={80} color={Colors.primary} fill={Colors.primary} />
        </View>
        <Text style={styles.appName}>{t.appName}</Text>
        <Text style={styles.tagline}>{t.tagline}</Text>
      </View>

      <View style={styles.aboutSection}>
        <Text style={styles.aboutTitle}>About Us</Text>
        <Text style={styles.aboutText}>
          RACE Saathi is built on a simple belief: sometimes, a little help can
          change someone's entire day.
        </Text>
        <Text style={styles.aboutText}>
          We connect senior citizens, and anyone else who may need support, with
          nearby people who want to help - in a simple, trusted, and human way.
        </Text>
        <Text style={styles.aboutText}>
          This is a free service. There is no money involved in asking for help
          or giving help.
        </Text>
        <Text style={styles.aboutTagline}>
          RACE Saathi - Helping Hands for Seniors.
        </Text>
      </View>

      <View style={styles.actions}>
        <Button
          title={t.needHelp}
          onPress={() => router.push('/login?role=senior')}
          variant="primary"
          size="large"
        />
        <View style={styles.spacer} />
        <Button
          title={t.wantToHelp}
          onPress={() => router.push('/login?role=volunteer')}
          variant="secondary"
          size="large"
        />
      </View>

      <View style={styles.languageSelector}>
        <Button
          title="English"
          onPress={() => setLanguage('en')}
          variant={language === 'en' ? 'primary' : 'outline'}
          size="medium"
          style={styles.languageButton}
        />
        <Button
          title="हिंदी"
          onPress={() => setLanguage('hi')}
          variant={language === 'hi' ? 'primary' : 'outline'}
          size="medium"
          style={styles.languageButton}
        />
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: Colors.background,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: Colors.textSecondary,
    fontWeight: '500',
  },
  content: {
    flexGrow: 1,
    padding: 24,
    justifyContent: 'center',
  },
  header: {
    alignItems: 'center',
    marginBottom: 48,
  },
  iconContainer: {
    marginBottom: 24,
  },
  appName: {
    fontSize: 42,
    fontWeight: '800',
    color: Colors.primary,
    marginBottom: 12,
    textAlign: 'center',
  },
  tagline: {
    fontSize: 22,
    color: Colors.textSecondary,
    textAlign: 'center',
    fontWeight: '500',
  },
  aboutSection: {
    backgroundColor: '#FFF9F5',
    borderRadius: 16,
    padding: 24,
    marginBottom: 48,
    borderWidth: 1,
    borderColor: '#FFE4D6',
  },
  aboutTitle: {
    fontSize: 24,
    fontWeight: '700',
    color: Colors.primary,
    marginBottom: 16,
    textAlign: 'center',
  },
  aboutText: {
    fontSize: 17,
    lineHeight: 26,
    color: Colors.text,
    marginBottom: 16,
    textAlign: 'center',
  },
  aboutTagline: {
    fontSize: 18,
    fontWeight: '600',
    color: Colors.primary,
    marginTop: 8,
    textAlign: 'center',
  },
  actions: {
    marginBottom: 40,
  },
  spacer: {
    height: 20,
  },
  languageSelector: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 16,
  },
  languageButton: {
    flex: 1,
  },
});
