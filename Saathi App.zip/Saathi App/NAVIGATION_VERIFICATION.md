# Navigation Flow Verification

## ✅ Verified Navigation Flows

### 1. Login Flow (Existing User)
**Path**: `login.tsx` → Role-specific home

**Sequence**:
1. User enters phone + OTP
2. OTP verified successfully
3. Profile found in database
4. **Navigate first**: `router.replace('/(senior)/home')` or `router.replace('/(volunteer)/home')`
5. **Save session after**: `requestAnimationFrame(() => saveSession(data))`
6. Landing page (`index.tsx`) detects `segments[0]` is already `'(senior)'` or `'(volunteer)'`
7. Landing page does NOT redirect (prevents race condition)
8. Role-specific layout mounts and displays home screen

**Result**: ✅ Single navigation, no flicker, no race condition

---

### 2. Profile Setup Flow (New User)
**Path**: `setup-profile.tsx` → Role-specific home

**Sequence**:
1. User completes profile form
2. Profile + volunteer data inserted into database
3. **Navigate first**: `router.replace('/(senior)/home')` or `router.replace('/(volunteer)/home')`
4. **Save session after**: `requestAnimationFrame(() => saveSession(data))`
5. Landing page detects segments already in auth group
6. Landing page does NOT redirect
7. Role-specific layout mounts

**Result**: ✅ Single navigation, no flicker, no race condition

---

### 3. Logout Flow
**Path**: Role-specific profile → Landing page

**Sequence**:
1. User clicks logout button
2. Confirmation alert shown
3. User confirms
4. `signOut()` called (clears localStorage, sets state to null)
5. `router.dismissAll()` clears navigation stack
6. `router.replace('/')` navigates to landing
7. Landing page resets `hasRedirected.current = false`
8. "Need Help" and "Want to Help" buttons available

**Result**: ✅ Clean logout, no reload, buttons work correctly

---

### 4. Session Persistence (Page Refresh)
**Path**: Page refresh → Auto-redirect to home

**Sequence**:
1. User refreshes page or closes/reopens app
2. AuthContext initializes
3. `getSession()` reads from localStorage
4. Session validated (not expired)
5. `phoneSession` state set
6. Landing page (`index.tsx`) effect fires
7. Checks: `phoneSession && !hasRedirected && !inAuthGroup`
8. Sets `hasRedirected.current = true`
9. **Deferred redirect**: `requestAnimationFrame(() => router.replace(...))`
10. Returns `null` during redirect (no flash)
11. Role-specific home loads

**Result**: ✅ Smooth redirect, no loading spinner flash

---

### 5. Role-Specific Layout Guards
**Path**: Protected layouts guard against unauthorized access

**Senior Layout (`(senior)/_layout.tsx`)**:
```typescript
useEffect(() => {
  if (!phoneSession || phoneSession.role !== 'senior') {
    router.replace('/');
  }
}, [phoneSession]);

if (!phoneSession || phoneSession.role !== 'senior') {
  return null;
}
```

**Volunteer Layout (`(volunteer)/_layout.tsx`)**:
```typescript
useEffect(() => {
  if (!phoneSession || phoneSession.role !== 'volunteer') {
    router.replace('/');
  }
}, [phoneSession]);

if (!phoneSession || phoneSession.role !== 'volunteer') {
  return null;
}
```

**Result**: ✅ Protected routes, role validation, clean redirects

---

## 🔑 Key Implementation Details

### Race Condition Prevention

**Problem**: Saving session triggers AuthContext update → Landing page redirect before manual navigation completes

**Solution**:
```typescript
// Navigate FIRST
router.replace('/(senior)/home');

// Save session AFTER (deferred to next frame)
requestAnimationFrame(() => {
  saveSession(sessionData);
});
```

---

### Double Redirect Prevention

**Problem**: Both login screen AND landing page try to navigate simultaneously

**Solution**:
```typescript
// Landing page checks if already in auth group
const inAuthGroup = segments[0] === '(senior)' || segments[0] === '(volunteer)';

if (phoneSession && !hasRedirected.current && !inAuthGroup) {
  // Only redirect if NOT already in auth group
  hasRedirected.current = true;
  requestAnimationFrame(() => {
    router.replace('/(senior)/home');
  });
}
```

---

### Loading Flicker Prevention

**Problem**: Loading spinner briefly shown during redirect

**Solution**:
```typescript
// Return null instead of loading spinner
if (phoneSession && hasRedirected.current) {
  return null;
}
```

---

## 🧪 Test Scenarios

### Scenario 1: Fresh Login
1. Open app (no session)
2. Click "Need Help"
3. Enter phone + OTP
4. Verify success
5. **Expected**: Direct navigation to senior home, no flash

### Scenario 2: Fresh Signup
1. Open app (no session)
2. Click "Want to Help"
3. Enter phone + OTP (new number)
4. Fill profile form
5. Submit
6. **Expected**: Direct navigation to volunteer home, no flash

### Scenario 3: Logout
1. Logged in as senior/volunteer
2. Go to profile
3. Click logout
4. Confirm
5. **Expected**: Clean transition to landing, buttons clickable

### Scenario 4: Page Refresh While Logged In
1. Logged in and on home screen
2. Refresh page (F5)
3. **Expected**: Brief moment then auto-redirect to home, no loading flash

### Scenario 5: Direct URL Access (Protected Route)
1. Logged out
2. Navigate directly to `/(senior)/home`
3. **Expected**: Immediate redirect to landing page

### Scenario 6: Wrong Role Access
1. Logged in as volunteer
2. Manually navigate to `/(senior)/home`
3. **Expected**: Immediate redirect to landing page

---

## 📊 Navigation State Machine

```
┌─────────────┐
│   Landing   │ (No session)
│   (index)   │
└──────┬──────┘
       │ Click "Need Help" or "Want to Help"
       ↓
┌─────────────┐
│    Login    │
│  (login)    │
└──────┬──────┘
       │
       ├─ Existing User ──→ Navigate to home → Save session
       │
       └─ New User ──────→ setup-profile
                            │
                            └──→ Navigate to home → Save session

┌─────────────────────────────────────────────────────────────┐
│  Role-Specific Home (Protected)                             │
│  - Senior: /(senior)/home                                   │
│  - Volunteer: /(volunteer)/home                             │
└──────────────────────────┬──────────────────────────────────┘
                           │
                           │ User navigates, uses app
                           │
                           ↓
                    ┌─────────────┐
                    │   Profile   │
                    │ Click logout│
                    └──────┬──────┘
                           │
                           │ signOut() → dismissAll() → replace('/')
                           ↓
                    ┌─────────────┐
                    │   Landing   │ (hasRedirected reset)
                    │   (index)   │
                    └─────────────┘
```

---

## ✅ All Checks Passed

- [x] Login navigates only once
- [x] Profile setup navigates only once
- [x] Logout navigates cleanly to landing
- [x] No loading spinner flicker
- [x] No double redirects
- [x] Session persistence works
- [x] Protected routes guarded
- [x] Role validation enforced
- [x] No full page reloads
- [x] TypeScript compiles without errors
- [x] Build succeeds
